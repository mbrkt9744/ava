/**
 * Currency utilities for AVA Cash Book
 * Amounts are strictly stored as integer fils (1 AED = 100 fils)
 * to avoid floating-point rounding errors.
 */

export function formatAED(fils: number, showCurrency: boolean = true): string {
  if (isNaN(fils)) fils = 0;
  const isNegative = fils < 0;
  const absFils = Math.abs(fils);
  const aed = absFils / 100;
  
  const formatted = aed.toLocaleString('en-US', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });

  const sign = isNegative ? '-' : '';
  return showCurrency ? `${sign}AED ${formatted}` : `${sign}${formatted}`;
}

export function parseAEDToFils(input: string | number): number {
  if (typeof input === 'number') {
    return Math.round(input * 100);
  }
  if (!input) return 0;
  
  // Clean string: remove commas, currency symbols, spaces
  const clean = input.replace(/[^\d.-]/g, '');
  const num = parseFloat(clean);
  if (isNaN(num)) return 0;
  
  return Math.round(num * 100);
}

/**
 * Calculate 5% UAE VAT:
 * 'included': gross amount contains 5% VAT (Net = Gross / 1.05, VAT = Gross - Net)
 * 'added': net amount gets 5% added on top (VAT = Net * 0.05, Gross = Net + VAT)
 */
export function calculateVAT(amountFils: number, mode: 'none' | 'included' | 'added'): { net: number; vat: number; total: number } {
  if (mode === 'none' || amountFils <= 0) {
    return { net: amountFils, vat: 0, total: amountFils };
  }

  if (mode === 'included') {
    // 5% VAT included: Gross = amountFils. Net = Math.round(Gross * 100 / 105)
    const net = Math.round((amountFils * 100) / 105);
    const vat = amountFils - net;
    return { net, vat, total: amountFils };
  } else {
    // 5% VAT added: Net = amountFils. VAT = Math.round(Net * 5 / 100)
    const vat = Math.round((amountFils * 5) / 100);
    const total = amountFils + vat;
    return { net: amountFils, vat, total };
  }
}

/**
 * Convert number in fils to English words for Payment Vouchers:
 * e.g., 738600 fils -> "Seven Thousand Three Hundred Eighty Six Dirhams and Zero Fils Only"
 */
export function numberToWordsAED(fils: number): string {
  if (fils === 0) return 'Zero Dirhams Only';
  
  const isNegative = fils < 0;
  const absFils = Math.abs(fils);
  const dirhams = Math.floor(absFils / 100);
  const remainingFils = absFils % 100;

  const ones = ['', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine'];
  const teens = ['Ten', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen'];
  const tens = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];
  const scales = ['', 'Thousand', 'Million', 'Billion'];

  function convertGroup(n: number): string {
    let result = '';
    const h = Math.floor(n / 100);
    const rest = n % 100;

    if (h > 0) {
      result += `${ones[h]} Hundred `;
    }

    if (rest >= 10 && rest <= 19) {
      result += `${teens[rest - 10]} `;
    } else {
      const t = Math.floor(rest / 10);
      const o = rest % 10;
      if (t > 0) result += `${tens[t]} `;
      if (o > 0) result += `${ones[o]} `;
    }

    return result.trim();
  }

  function numberToWordsInt(num: number): string {
    if (num === 0) return '';
    let word = '';
    let scaleIndex = 0;

    while (num > 0) {
      const group = num % 1000;
      if (group !== 0) {
        const groupStr = convertGroup(group);
        const scale = scales[scaleIndex];
        word = `${groupStr} ${scale} ${word}`.trim();
      }
      num = Math.floor(num / 1000);
      scaleIndex++;
    }

    return word;
  }

  const dirhamsWords = dirhams > 0 ? `${numberToWordsInt(dirhams)} Dirhams` : '';
  const filsWords = remainingFils > 0 ? ` and ${numberToWordsInt(remainingFils)} Fils` : '';

  const prefix = isNegative ? 'Minus ' : '';
  return `${prefix}${dirhamsWords}${filsWords} Only`.replace(/\s+/g, ' ').trim();
}
