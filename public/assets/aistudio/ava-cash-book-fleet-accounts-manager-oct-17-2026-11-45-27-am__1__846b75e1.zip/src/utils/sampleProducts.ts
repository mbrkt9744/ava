import { SampleProduct } from '../types';

function createSvgDataUrl(svgString: string): string {
  return `data:image/svg+xml;utf8,${encodeURIComponent(svgString.trim())}`;
}

export const SAMPLE_PRODUCTS: SampleProduct[] = [
  {
    id: 'solace_cold_brew',
    name: 'SOLACE Cold Brew',
    category: 'Beverage & Packaging',
    tagline: 'Nitro Cold Brew Organic Single Origin',
    colors: ['#0f172a', '#e2b34a', '#f8fafc'],
    dataUrl: createSvgDataUrl(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 600 700" width="600" height="700">
        <defs>
          <linearGradient id="bgGrad" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stop-color="#18181b"/>
            <stop offset="100%" stop-color="#09090b"/>
          </linearGradient>
          <linearGradient id="canBody" x1="0" y1="0" x2="1" y2="0">
            <stop offset="0%" stop-color="#1c1917"/>
            <stop offset="18%" stop-color="#292524"/>
            <stop offset="50%" stop-color="#44403c"/>
            <stop offset="82%" stop-color="#292524"/>
            <stop offset="100%" stop-color="#141211"/>
          </linearGradient>
          <linearGradient id="goldAcc" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stop-color="#fef08a"/>
            <stop offset="50%" stop-color="#d97706"/>
            <stop offset="100%" stop-color="#b45309"/>
          </linearGradient>
          <linearGradient id="metallicCanTop" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stop-color="#e4e4e7"/>
            <stop offset="50%" stop-color="#a1a1aa"/>
            <stop offset="100%" stop-color="#71717a"/>
          </linearGradient>
          <filter id="canShadow" x="-20%" y="-20%" width="140%" height="140%">
            <feDropShadow dx="0" dy="25" stdDeviation="20" flood-color="#000" flood-opacity="0.6"/>
          </filter>
        </defs>
        
        <rect width="600" height="700" fill="url(#bgGrad)"/>
        
        <!-- Soft Studio Backdrop Spotlight -->
        <circle cx="300" cy="350" r="260" fill="#27272a" opacity="0.35"/>
        
        <!-- Cold Brew Can Shape -->
        <g filter="url(#canShadow)">
          <!-- Top rim & lid -->
          <ellipse cx="300" cy="140" rx="95" ry="18" fill="url(#metallicCanTop)"/>
          <ellipse cx="300" cy="138" rx="85" ry="14" fill="#a1a1aa"/>
          <ellipse cx="300" cy="138" rx="80" ry="12" fill="#52525b"/>
          <!-- Tab -->
          <rect x="290" y="132" width="20" height="12" rx="3" fill="#e4e4e7"/>
          
          <!-- Can Shoulder -->
          <path d="M 205,140 C 205,170 190,185 190,200 L 410,200 C 410,185 395,170 395,140 Z" fill="url(#metallicCanTop)"/>
          
          <!-- Can Body Cylinder -->
          <rect x="190" y="195" width="220" height="360" rx="8" fill="url(#canBody)"/>
          
          <!-- Can Bottom Rim -->
          <path d="M 190,550 C 190,565 205,580 220,585 L 380,585 C 395,580 410,565 410,550 Z" fill="url(#metallicCanTop)"/>
          <ellipse cx="300" cy="585" rx="80" ry="10" fill="#71717a"/>
        </g>
        
        <!-- Label Artwork on Can -->
        <g id="brandArtwork">
          <!-- Geometric Emblem -->
          <circle cx="300" cy="275" r="32" fill="none" stroke="url(#goldAcc)" stroke-width="2.5"/>
          <polygon points="300,250 325,290 275,290" fill="none" stroke="url(#goldAcc)" stroke-width="2"/>
          <circle cx="300" cy="277" r="6" fill="url(#goldAcc)"/>
          
          <!-- Brand Name Typography -->
          <text x="300" y="340" font-family="'Plus Jakarta Sans', sans-serif" font-size="28" font-weight="800" fill="#ffffff" letter-spacing="6" text-anchor="middle">SOLACE</text>
          <text x="300" y="365" font-family="'Plus Jakarta Sans', sans-serif" font-size="11" font-weight="600" fill="url(#goldAcc)" letter-spacing="4" text-anchor="middle">NITRO COLD BREW</text>
          
          <!-- Horizontal Rule -->
          <line x1="240" y1="385" x2="360" y2="385" stroke="url(#goldAcc)" stroke-width="1" opacity="0.6"/>
          
          <!-- Product Notes & Specs -->
          <text x="300" y="410" font-family="'Plus Jakarta Sans', sans-serif" font-size="9" font-weight="500" fill="#a1a1aa" letter-spacing="2" text-anchor="middle">SINGLE ORIGIN ETHIOPIA</text>
          <text x="300" y="428" font-family="'Plus Jakarta Sans', sans-serif" font-size="8.5" font-weight="400" fill="#71717a" letter-spacing="1.5" text-anchor="middle">BLACK HONEY PROCESS · 0G SUGAR</text>
          <text x="300" y="445" font-family="'Plus Jakarta Sans', sans-serif" font-size="8" font-weight="400" fill="#71717a" letter-spacing="1" text-anchor="middle">NOTES OF JASMINE &amp; STONE FRUIT</text>
          
          <!-- Volume Badge -->
          <rect x="270" y="475" width="60" height="22" rx="4" fill="#27272a" stroke="#3f3f46" stroke-width="1"/>
          <text x="300" y="490" font-family="'Plus Jakarta Sans', sans-serif" font-size="9" font-weight="700" fill="#e4e4e7" letter-spacing="1" text-anchor="middle">12 FL OZ (355ml)</text>
        </g>
        
        <!-- Subtle Studio Gloss Reflection Strip -->
        <rect x="215" y="195" width="22" height="360" fill="#ffffff" opacity="0.08"/>
      </svg>
    `),
  },
  {
    id: 'aerotrack_earbuds',
    name: 'AERO Apex Earbuds',
    category: 'Electronics & Audio',
    tagline: 'Titanium Acoustic Noise Cancelling',
    colors: ['#0f172a', '#06b6d4', '#e2e8f0'],
    dataUrl: createSvgDataUrl(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 600 700" width="600" height="700">
        <defs>
          <linearGradient id="darkBg" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stop-color="#0f172a"/>
            <stop offset="100%" stop-color="#020617"/>
          </linearGradient>
          <linearGradient id="titaniumCase" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stop-color="#334155"/>
            <stop offset="40%" stop-color="#1e293b"/>
            <stop offset="100%" stop-color="#0f172a"/>
          </linearGradient>
          <linearGradient id="cyanGlow" x1="0" y1="0" x2="1" y2="0">
            <stop offset="0%" stop-color="#06b6d4"/>
            <stop offset="100%" stop-color="#3b82f6"/>
          </linearGradient>
          <filter id="shadowEar" x="-20%" y="-20%" width="140%" height="140%">
            <feDropShadow dx="0" dy="20" stdDeviation="18" flood-color="#000" flood-opacity="0.7"/>
          </filter>
        </defs>
        
        <rect width="600" height="700" fill="url(#darkBg)"/>
        
        <!-- Case Pedestal Glow -->
        <ellipse cx="300" cy="500" rx="190" ry="40" fill="#06b6d4" opacity="0.12"/>
        
        <g filter="url(#shadowEar)">
          <!-- Main Earbuds Charging Case Body -->
          <rect x="180" y="240" width="240" height="190" rx="42" fill="url(#titaniumCase)" stroke="#475569" stroke-width="2"/>
          
          <!-- Lid Separation Seam -->
          <line x1="180" y1="300" x2="420" y2="300" stroke="#0f172a" stroke-width="3"/>
          <line x1="182" y1="302" x2="418" y2="302" stroke="#64748b" stroke-width="1" opacity="0.5"/>
          
          <!-- Glowing LED Indicator Bar -->
          <rect x="280" y="318" width="40" height="4" rx="2" fill="url(#cyanGlow)"/>
          
          <!-- Brand Engraving -->
          <text x="300" y="370" font-family="'Plus Jakarta Sans', sans-serif" font-size="20" font-weight="800" fill="#f8fafc" letter-spacing="4" text-anchor="middle">AERO</text>
          <text x="300" y="390" font-family="'Plus Jakarta Sans', sans-serif" font-size="9" font-weight="600" fill="#38bdf8" letter-spacing="3" text-anchor="middle">APEX WIRELESS</text>
        </g>
        
        <!-- Left Earbud floating next to case -->
        <g filter="url(#shadowEar)">
          <circle cx="210" cy="180" r="26" fill="#1e293b" stroke="#38bdf8" stroke-width="1.5"/>
          <rect x="202" y="196" width="16" height="40" rx="8" fill="#334155"/>
          <circle cx="210" cy="180" r="8" fill="url(#cyanGlow)"/>
        </g>
        
        <!-- Right Earbud floating next to case -->
        <g filter="url(#shadowEar)">
          <circle cx="390" cy="180" r="26" fill="#1e293b" stroke="#38bdf8" stroke-width="1.5"/>
          <rect x="382" y="196" width="16" height="40" rx="8" fill="#334155"/>
          <circle cx="390" cy="180" r="8" fill="url(#cyanGlow)"/>
        </g>
      </svg>
    `),
  },
  {
    id: 'terra_serum',
    name: 'TERRA Botanic Serum',
    category: 'Skincare & Cosmetics',
    tagline: 'Bio-Retinol & Botanical Squalane',
    colors: ['#78350f', '#fef3c7', '#065f46'],
    dataUrl: createSvgDataUrl(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 600 700" width="600" height="700">
        <defs>
          <linearGradient id="warmStudioBg" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stop-color="#1c1917"/>
            <stop offset="100%" stop-color="#0c0a09"/>
          </linearGradient>
          <linearGradient id="amberGlass" x1="0" y1="0" x2="1" y2="0">
            <stop offset="0%" stop-color="#78350f"/>
            <stop offset="35%" stop-color="#b45309"/>
            <stop offset="65%" stop-color="#d97706"/>
            <stop offset="100%" stop-color="#78350f"/>
          </linearGradient>
          <filter id="bottleShadow" x="-20%" y="-20%" width="140%" height="140%">
            <feDropShadow dx="0" dy="25" stdDeviation="22" flood-color="#000" flood-opacity="0.6"/>
          </filter>
        </defs>
        
        <rect width="600" height="700" fill="url(#warmStudioBg)"/>
        <circle cx="300" cy="400" r="240" fill="#451a03" opacity="0.25"/>
        
        <g filter="url(#bottleShadow)">
          <!-- Dropper bulb & collar -->
          <rect x="282" y="110" width="36" height="36" rx="16" fill="#18181b"/>
          <rect x="274" y="146" width="52" height="32" rx="4" fill="#27272a" stroke="#d97706" stroke-width="1"/>
          
          <!-- Bottle Neck -->
          <rect x="280" y="178" width="40" height="30" fill="url(#amberGlass)"/>
          
          <!-- Bottle Body -->
          <rect x="220" y="208" width="160" height="340" rx="18" fill="url(#amberGlass)"/>
          
          <!-- Minimalist Cream Label -->
          <rect x="232" y="248" width="136" height="250" rx="4" fill="#fdfbf7"/>
          
          <!-- Label Branding -->
          <text x="300" y="285" font-family="'Plus Jakarta Sans', sans-serif" font-size="18" font-weight="800" fill="#1c1917" letter-spacing="4" text-anchor="middle">TERRA</text>
          <text x="300" y="302" font-family="'Plus Jakarta Sans', sans-serif" font-size="8" font-weight="600" fill="#047857" letter-spacing="3" text-anchor="middle">BOTANICALS</text>
          
          <line x1="255" y1="316" x2="345" y2="316" stroke="#e5e5e5" stroke-width="1"/>
          
          <text x="300" y="340" font-family="'Plus Jakarta Sans', sans-serif" font-size="11" font-weight="700" fill="#292524" letter-spacing="1" text-anchor="middle">RENEWAL SERUM</text>
          <text x="300" y="358" font-family="'Plus Jakarta Sans', sans-serif" font-size="8" font-weight="500" fill="#78716c" letter-spacing="0.5" text-anchor="middle">Bakuchiol &amp; 100% Squalane</text>
          <text x="300" y="374" font-family="'Plus Jakarta Sans', sans-serif" font-size="7.5" font-weight="400" fill="#a8a29e" letter-spacing="0.5" text-anchor="middle">Deep Cellular Hydration</text>
          
          <!-- Botanical Leaf Icon -->
          <circle cx="300" cy="415" r="14" fill="#ecfdf5"/>
          <path d="M 300,406 C 308,414 306,424 300,426 C 294,424 292,414 300,406 Z" fill="#059669"/>
          
          <text x="300" y="455" font-family="'Plus Jakarta Sans', sans-serif" font-size="8" font-weight="600" fill="#57534e" letter-spacing="1" text-anchor="middle">MADE IN FRANCE</text>
          <text x="300" y="475" font-family="'Plus Jakarta Sans', sans-serif" font-size="8.5" font-weight="700" fill="#1c1917" letter-spacing="1" text-anchor="middle">30 ML / 1.0 FL OZ</text>
        </g>
        
        <!-- Glass Specular Highlight -->
        <rect x="230" y="215" width="10" height="325" rx="5" fill="#ffffff" opacity="0.15"/>
      </svg>
    `),
  },
  {
    id: 'verve_energy',
    name: 'VERVE Electro Energy',
    category: 'Beverage & Streetwear',
    tagline: 'Zero Sugar Electric Citrus Wave',
    colors: ['#0284c7', '#a3e635', '#0f172a'],
    dataUrl: createSvgDataUrl(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 600 700" width="600" height="700">
        <defs>
          <linearGradient id="vibrantCan" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stop-color="#0284c7"/>
            <stop offset="50%" stop-color="#2563eb"/>
            <stop offset="100%" stop-color="#4f46e5"/>
          </linearGradient>
          <linearGradient id="neonGreen" x1="0" y1="0" x2="1" y2="0">
            <stop offset="0%" stop-color="#a3e635"/>
            <stop offset="100%" stop-color="#4ade80"/>
          </linearGradient>
          <filter id="verveShadow" x="-20%" y="-20%" width="140%" height="140%">
            <feDropShadow dx="0" dy="25" stdDeviation="20" flood-color="#0284c7" flood-opacity="0.3"/>
          </filter>
        </defs>
        
        <rect width="600" height="700" fill="#090d16"/>
        
        <!-- Dynamic Street Lines -->
        <line x1="80" y1="100" x2="520" y2="600" stroke="#1e293b" stroke-width="4"/>
        <line x1="120" y1="600" x2="480" y2="100" stroke="#1e293b" stroke-width="4"/>
        
        <g filter="url(#verveShadow)">
          <!-- Slim Energy Can -->
          <ellipse cx="300" cy="150" rx="80" ry="15" fill="#94a3b8"/>
          <ellipse cx="300" cy="148" rx="72" ry="12" fill="#64748b"/>
          <rect x="292" y="142" width="16" height="10" rx="3" fill="#cbd5e1"/>
          
          <path d="M 220,150 L 210,190 L 390,190 L 380,150 Z" fill="#94a3b8"/>
          
          <rect x="210" y="190" width="180" height="380" rx="8" fill="url(#vibrantCan)"/>
          
          <!-- Lightning Bolt Slash Graphics -->
          <polygon points="340,210 260,340 310,340 240,480 360,320 300,320" fill="url(#neonGreen)"/>
          
          <!-- Typography -->
          <text x="300" y="320" font-family="'Plus Jakarta Sans', sans-serif" font-size="34" font-weight="900" font-style="italic" fill="#ffffff" letter-spacing="4" text-anchor="middle">VERVE</text>
          <text x="300" y="350" font-family="'Plus Jakarta Sans', sans-serif" font-size="12" font-weight="800" fill="#a3e635" letter-spacing="5" text-anchor="middle">ELECTRO NITRO</text>
          
          <text x="300" y="510" font-family="'Plus Jakarta Sans', sans-serif" font-size="10" font-weight="700" fill="#ffffff" letter-spacing="2" text-anchor="middle">200MG NATURAL CAFFEINE</text>
          <text x="300" y="530" font-family="'Plus Jakarta Sans', sans-serif" font-size="9" font-weight="600" fill="#93c5fd" letter-spacing="1.5" text-anchor="middle">ZERO SUGAR · B-COMPLEX · 16 FL OZ</text>
        </g>
      </svg>
    `),
  },
];
