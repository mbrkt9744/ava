import { Transaction, Settings } from '../types/cashbook';

export interface ChequeRecord {
  chq: string;
  tx?: Transaction;
  date: string;
  payee: string;
  desc: string;
  amountFils: number;
  status: 'To clear' | 'Cleared' | 'Returned' | 'Cancelled' | 'MISSING';
  clearedOn?: string;
  voucherNo?: string;
}

export function analyzeCheques(transactions: Transaction[], settings: Settings) {
  const activeTx = transactions.filter((t) => !t.deleted);
  
  // Track returned cheques
  const returnedSet = new Set<string>();
  activeTx.forEach((t) => {
    if (t.acc === 'Bank' && t.type === 'in' && t.chq) {
      returnedSet.add(t.chq.trim());
    }
  });

  const seenCheques = new Map<string, ChequeRecord>();

  // Collect written cheques (outflow on Bank account with cheque number)
  activeTx.forEach((t) => {
    if (t.acc === 'Bank' && t.type === 'out' && t.chq) {
      const numStr = t.chq.trim();
      let status: 'To clear' | 'Cleared' | 'Returned' | 'Cancelled' = 'To clear';

      if (returnedSet.has(numStr)) {
        status = 'Returned';
      } else if (t.clr && t.clr.trim() !== '') {
        status = 'Cleared';
      }

      seenCheques.set(numStr, {
        chq: numStr,
        tx: t,
        date: t.date,
        payee: t.party || '—',
        desc: t.desc || '',
        amountFils: t.amt,
        status,
        clearedOn: t.clr,
        voucherNo: t.pv,
      });
    }
  });

  // Include cancelled cheques recorded in settings.chqX
  if (settings.chqX) {
    Object.entries(settings.chqX).forEach(([chqNum, val]) => {
      const numStr = chqNum.trim();
      seenCheques.set(numStr, {
        chq: numStr,
        date: val.date || '',
        payee: '—',
        desc: val.note || 'Cancelled cheque leaf',
        amountFils: 0,
        status: 'Cancelled',
      });
    });
  }

  // Find missing cheque leaves
  const numericList: number[] = [];
  seenCheques.forEach((_, key) => {
    const parsed = parseInt(key, 10);
    if (!isNaN(parsed) && parsed > 0) {
      numericList.push(parsed);
    }
  });

  if (numericList.length > 0) {
    const min = Math.min(...numericList);
    const max = Math.max(...numericList);

    // Limit check window to 1500 to avoid runaway loops
    if (max - min < 1500) {
      for (let i = min; i <= max; i++) {
        const padded = String(i).padStart(6, '0');
        if (!seenCheques.has(padded)) {
          seenCheques.set(padded, {
            chq: padded,
            date: '',
            payee: '—',
            desc: 'Not in books – check the physical cheque stub',
            amountFils: 0,
            status: 'MISSING',
          });
        }
      }
    }
  }

  const allList = Array.from(seenCheques.values()).sort((a, b) => a.chq.localeCompare(b.chq));

  const toClearList = allList.filter((c) => c.status === 'To clear');
  const clearedList = allList.filter((c) => c.status === 'Cleared');
  const returnedList = allList.filter((c) => c.status === 'Returned');
  const cancelledList = allList.filter((c) => c.status === 'Cancelled');
  const missingList = allList.filter((c) => c.status === 'MISSING');

  const toClearTotalFils = toClearList.reduce((sum, c) => sum + c.amountFils, 0);
  const clearedTotalFils = clearedList.reduce((sum, c) => sum + c.amountFils, 0);

  return {
    allList,
    toClearList,
    clearedList,
    returnedList,
    cancelledList,
    missingList,
    toClearTotalFils,
    clearedTotalFils,
  };
}

export function calculateAccountBalances(transactions: Transaction[], settings: Settings) {
  let bankIn = 0;
  let bankOut = 0;
  let pettyIn = 0;
  let pettyOut = 0;

  transactions.forEach((t) => {
    if (t.deleted) return;
    if (t.acc === 'Bank') {
      if (t.type === 'in') bankIn += t.amt;
      else bankOut += t.amt;
    } else {
      if (t.type === 'in') pettyIn += t.amt;
      else pettyOut += t.amt;
    }
  });

  const bankOpening = settings.ob?.Bank || 0;
  const pettyOpening = settings.ob?.Petty || 0;

  const bankBalance = bankOpening + bankIn - bankOut;
  const pettyBalance = pettyOpening + pettyIn - pettyOut;
  const totalInHand = bankBalance + pettyBalance;

  return {
    bankOpening,
    pettyOpening,
    bankIn,
    bankOut,
    bankBalance,
    pettyIn,
    pettyOut,
    pettyBalance,
    totalInHand,
  };
}
