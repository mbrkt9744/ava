export function todayUAE(): string {
  try {
    const formatter = new Intl.DateTimeFormat('en-CA', {
      timeZone: 'Asia/Dubai',
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
    });
    return formatter.format(new Date());
  } catch {
    return new Date().toISOString().slice(0, 10);
  }
}

export function formatDate(dateStr: string): string {
  if (!dateStr) return '—';
  try {
    const [y, m, d] = dateStr.split('-');
    if (!y || !m || !d) return dateStr;
    const date = new Date(Number(y), Number(m) - 1, Number(d));
    return date.toLocaleDateString('en-GB', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
    });
  } catch {
    return dateStr;
  }
}

export function daysUntil(targetDateStr: string): number {
  if (!targetDateStr) return 999999;
  const today = todayUAE();
  const t0 = Date.parse(today + 'T00:00:00Z');
  const t1 = Date.parse(targetDateStr + 'T00:00:00Z');
  if (isNaN(t0) || isNaN(t1)) return 999999;
  return Math.round((t1 - t0) / (1000 * 60 * 60 * 24));
}

export function getExpiryStatus(regDate: string, insDate: string): {
  status: 'EXPIRED' | 'RENEW_SOON' | 'OK' | 'NO_DATES';
  daysLeft: number;
  label: string;
  badgeClass: string;
} {
  const dr = regDate ? daysUntil(regDate) : 999999;
  const di = insDate ? daysUntil(insDate) : 999999;
  const minDays = Math.min(dr, di);

  if (minDays === 999999) {
    return {
      status: 'NO_DATES',
      daysLeft: minDays,
      label: 'No dates',
      badgeClass: 'bg-slate-100 text-slate-700 border-slate-200',
    };
  }

  if (minDays < 0) {
    return {
      status: 'EXPIRED',
      daysLeft: minDays,
      label: `EXPIRED (${Math.abs(minDays)}d ago)`,
      badgeClass: 'bg-rose-100 text-rose-800 border-rose-300 font-semibold',
    };
  }

  if (minDays <= 30) {
    return {
      status: 'RENEW_SOON',
      daysLeft: minDays,
      label: `Renew soon (${minDays}d left)`,
      badgeClass: 'bg-amber-100 text-amber-800 border-amber-300 font-semibold',
    };
  }

  return {
    status: 'OK',
    daysLeft: minDays,
    label: `OK (${minDays}d left)`,
    badgeClass: 'bg-emerald-100 text-emerald-800 border-emerald-300',
  };
}
