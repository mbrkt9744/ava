import { CashbookData, Transaction, Settings } from '../types/cashbook';
import { INITIAL_DATA } from '../data/initialData';

const STORAGE_KEY = 'ava_cashbook_data_v3';

export function loadCashbookData(): CashbookData {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      saveCashbookData(INITIAL_DATA);
      return INITIAL_DATA;
    }
    const parsed = JSON.parse(raw);
    if (!parsed || !parsed.tx || !parsed.settings) {
      return INITIAL_DATA;
    }
    return parsed;
  } catch (err) {
    console.error('Failed to load cashbook data from localStorage:', err);
    return INITIAL_DATA;
  }
}

export function saveCashbookData(data: CashbookData): void {
  try {
    data.settings.updatedAt = Date.now();
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  } catch (err) {
    console.error('Failed to save cashbook data to localStorage:', err);
  }
}

export function downloadBackupJSON(data: CashbookData): void {
  const exportCopy = {
    ...data,
    exported: new Date().toISOString(),
  };

  const jsonStr = JSON.stringify(exportCopy, null, 2);
  const blob = new Blob([jsonStr], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const dateStr = new Date().toISOString().slice(0, 10);
  const a = document.createElement('a');
  a.href = url;
  a.download = `AVA-CashBook-Backup-${dateStr}.json`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

export function exportTransactionsCSV(transactions: Transaction[], settings: Settings): void {
  const headers = [
    'Date',
    'Ref',
    'Voucher No',
    'Account',
    'Type',
    'Amount (AED)',
    'VAT (AED)',
    'Net of VAT (AED)',
    'Description',
    'Payee / Party',
    'Category',
    'Sub-category',
    'Vehicle',
    'Driver',
    'Cheque No',
    'Cleared Date',
    'Status',
  ];

  const rows = transactions
    .filter((t) => !t.deleted)
    .sort((a, b) => b.date.localeCompare(a.date))
    .map((t) => {
      const aed = (t.amt / 100).toFixed(2);
      const vat = ((t.vat || 0) / 100).toFixed(2);
      const net = ((t.amt - (t.vat || 0)) / 100).toFixed(2);
      const status = t.acc === 'Bank' && t.chq ? (t.clr ? 'Cleared' : 'To Clear') : 'Settled';

      const cells = [
        t.date,
        t.ref || '',
        t.pv || '',
        t.acc,
        t.type === 'in' ? 'Money In' : 'Money Out',
        t.type === 'in' ? aed : `-${aed}`,
        vat,
        net,
        t.desc || '',
        t.party || '',
        t.cat || '',
        t.sub || '',
        t.veh || '',
        t.drv || '',
        t.chq || '',
        t.clr || '',
        status,
      ];

      // Sanitize formula characters (=, +, -, @) and quote strings
      return cells.map((val) => {
        let str = String(val ?? '');
        if (/^[=+\-@]/.test(str)) {
          str = `'${str}`;
        }
        return `"${str.replace(/"/g, '""')}"`;
      }).join(',');
    });

  const csvContent = '\uFEFF' + [headers.join(','), ...rows].join('\r\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `AVA-CashBook-Ledger-${new Date().toISOString().slice(0, 10)}.csv`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
