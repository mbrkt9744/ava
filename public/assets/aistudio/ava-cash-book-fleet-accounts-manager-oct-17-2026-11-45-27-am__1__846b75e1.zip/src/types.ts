export type MediumCategory = 'drinkware' | 'outdoor' | 'apparel' | 'retail' | 'print_digital';

export interface MediumOption {
  id: string;
  name: string;
  category: MediumCategory;
  defaultRatio: '1:1' | '16:9' | '4:3' | '3:4' | '9:16';
  description: string;
  tagline: string;
  badge: string;
}

export type StylePresetId = 'studio_minimal' | 'streetwear_urban' | 'cyberpunk_night' | 'luxury_editorial' | 'sunny_outdoor';

export interface StylePreset {
  id: StylePresetId;
  name: string;
  description: string;
  lightingHint: string;
  previewColor: string;
}

export interface ConsistencyOptions {
  lockColorway: boolean;
  highFidelityTexture: boolean;
  cleanBackground: boolean;
}

export interface GeneratedMockup {
  id: string;
  imageUrl: string;
  mediumId: string;
  mediumTitle: string;
  aspectRatio: string;
  modelUsed: string;
  promptUsed: string;
  notes?: string;
  timestamp: number;
  promptInstruction?: string;
  parentMockupId?: string;
  versions?: {
    id: string;
    imageUrl: string;
    timestamp: number;
    prompt: string;
  }[];
}

export interface SampleProduct {
  id: string;
  name: string;
  category: string;
  tagline: string;
  colors: string[];
  dataUrl: string;
}
