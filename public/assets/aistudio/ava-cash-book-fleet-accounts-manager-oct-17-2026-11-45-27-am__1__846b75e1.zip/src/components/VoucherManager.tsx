import React, { useState } from 'react';
import { Transaction, Settings, VoucherLine } from '../types/cashbook';
import { formatAED, numberToWordsAED, parseAEDToFils } from '../utils/currency';
import { formatDate, todayUAE } from '../utils/date';
import {
  FileText,
  PlusCircle,
  Printer,
  X,
  CreditCard,
  Plus,
  Trash2,
  CheckCircle2,
  Clock,
  ArrowLeft,
} from 'lucide-react';

interface VoucherManagerProps {
  transactions: Transaction[];
  settings: Settings;
  onSaveVoucher: (voucherTx: Transaction) => void;
  selectedVoucherNo?: string | null;
}

export const VoucherManager: React.FC<VoucherManagerProps> = ({
  transactions,
  settings,
  onSaveVoucher,
  selectedVoucherNo,
}) => {
  // All transactions that are Payment Vouchers (have pv field)
  const vouchers = transactions
    .filter((t) => !t.deleted && t.pv)
    .sort((a, b) => (b.pv || '').localeCompare(a.pv || ''));

  const [activeVoucher, setActiveVoucher] = useState<Transaction | null>(() => {
    if (selectedVoucherNo) {
      return transactions.find((t) => t.pv === selectedVoucherNo) || null;
    }
    return vouchers[0] || null;
  });

  const [isCreating, setIsCreating] = useState<boolean>(false);

  // New Voucher Form State
  const [pvNumber, setPvNumber] = useState<string>('');
  const [date, setDate] = useState<string>(todayUAE());
  const [party, setParty] = useState<string>('');
  const [pm, setPm] = useState<string>('Cheque');
  const [chq, setChq] = useState<string>('');
  const [lines, setLines] = useState<VoucherLine[]>([
    { d: '', f: '', t: '', q: 1, u: 0, a: 0 },
  ]);
  const [hasVat, setHasVat] = useState<boolean>(false);
  const [veh, setVeh] = useState<string>('');

  const openNewVoucherModal = () => {
    // Generate next voucher number, e.g. PV-10/2026-10
    const [year, month] = todayUAE().split('-');
    const prefix = `PV-${month}/${year}-`;
    const existingNums = vouchers
      .filter((v) => v.pv?.startsWith(prefix))
      .map((v) => {
        const parts = v.pv?.split('-');
        const lastPart = parts ? parts[parts.length - 1] : '0';
        return parseInt(lastPart, 10) || 0;
      });
    const nextSeq = (Math.max(0, ...existingNums) + 1).toString().padStart(2, '0');
    setPvNumber(`${prefix}${nextSeq}`);
    setDate(todayUAE());
    setParty('');
    setPm('Cheque');
    setChq('');
    setVeh('');
    setLines([{ d: '', f: '', t: '', q: 1, u: 0, a: 0 }]);
    setHasVat(false);
    setIsCreating(true);
  };

  const addLine = () => {
    setLines([...lines, { d: '', f: '', t: '', q: 1, u: 0, a: 0 }]);
  };

  const removeLine = (idx: number) => {
    if (lines.length === 1) return;
    setLines(lines.filter((_, i) => i !== idx));
  };

  const updateLine = (idx: number, field: keyof VoucherLine, val: any) => {
    const updated = [...lines];
    const current = { ...updated[idx], [field]: val };

    if (field === 'q' || field === 'u') {
      const q = typeof current.q === 'number' ? current.q : parseFloat(current.q) || 1;
      const u = typeof current.u === 'number' ? current.u : parseAEDToFils(current.u);
      current.a = Math.round(q * u);
    }

    updated[idx] = current;
    setLines(updated);
  };

  const totalLinesFils = lines.reduce((sum, l) => sum + (l.a || 0), 0);
  const vatFils = hasVat ? Math.round(totalLinesFils * 0.05) : 0;
  const grandTotalFils = totalLinesFils + vatFils;

  const handleCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (grandTotalFils <= 0) {
      alert('Please enter at least one line with a valid price/quantity.');
      return;
    }
    if (!party.trim()) {
      alert('Please specify the payee name.');
      return;
    }

    const firstLineDesc = lines[0]?.d || 'Subcontract bus hire';
    const newTx: Transaction = {
      uid: `pv-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 6)}`,
      date,
      acc: 'Bank',
      type: 'out',
      amt: grandTotalFils,
      vat: vatFils,
      desc: lines.map((l) => l.d).filter(Boolean).join(' + ') || firstLineDesc,
      party: party.trim(),
      cat: 'Vehicle hire (subcontract)',
      sub: 'Bus hire',
      veh: veh || '',
      ref: pvNumber,
      pv: pvNumber,
      pm,
      chq: pm === 'Cheque' ? chq.trim() : '',
      clr: '',
      lines,
      by: 'Office Voucher Entry',
      createdAt: Date.now(),
      updatedAt: Date.now(),
      deleted: false,
    };

    onSaveVoucher(newTx);
    setActiveVoucher(newTx);
    setIsCreating(false);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6">
      {/* Top Banner and Navigation */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-5 flex flex-wrap items-center justify-between gap-4 no-print">
        <div>
          <h1 className="text-xl font-extrabold text-[#0b3d3a] tracking-tight">
            Official Payment Vouchers (PV)
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Standard UAE passenger transport payment vouchers with line item breakdown and printable format
          </p>
        </div>

        <button
          onClick={openNewVoucherModal}
          className="px-4 py-2 text-xs font-bold rounded-lg bg-[#0b3d3a] hover:bg-[#072725] text-white transition flex items-center gap-1.5 shadow-sm"
        >
          <PlusCircle className="w-3.5 h-3.5 text-[#d6b265]" />
          <span>Create Payment Voucher</span>
        </button>
      </div>

      {/* Main Grid: Vouchers List (Left) & Voucher Preview / Printable View (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column: Vouchers List */}
        <div className="lg:col-span-4 bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden no-print">
          <div className="p-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
            <span className="font-bold text-xs text-slate-800">
              Generated Vouchers ({vouchers.length})
            </span>
            <span className="text-[11px] text-slate-500">October 2026</span>
          </div>

          <div className="divide-y divide-slate-100 max-h-[700px] overflow-y-auto">
            {vouchers.map((v) => {
              const isSelected = activeVoucher?.uid === v.uid;
              return (
                <button
                  key={v.uid}
                  onClick={() => setActiveVoucher(v)}
                  className={`w-full text-left p-3.5 transition-colors flex items-start justify-between gap-3 ${
                    isSelected ? 'bg-teal-50/90 border-l-4 border-[#0b3d3a]' : 'hover:bg-slate-50'
                  }`}
                >
                  <div className="space-y-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="font-mono font-bold text-xs text-[#0b3d3a]">{v.pv}</span>
                      <span className="text-[11px] text-slate-400 font-mono">{formatDate(v.date)}</span>
                    </div>
                    <div className="font-semibold text-xs text-slate-900 truncate">
                      {v.party || '—'}
                    </div>
                    <div className="text-[11px] text-slate-500 truncate">{v.desc}</div>
                    {v.chq && (
                      <div className="text-[10px] text-teal-800 font-mono flex items-center gap-1">
                        <CreditCard className="w-3 h-3" /> Chq #{v.chq} {v.clr ? '(Cleared)' : '(To clear)'}
                      </div>
                    )}
                  </div>

                  <div className="text-right shrink-0">
                    <div className="font-mono font-bold text-xs text-slate-900">
                      {formatAED(v.amt)}
                    </div>
                    <span className="text-[10px] px-1.5 py-0.5 rounded font-semibold bg-slate-100 text-slate-600 mt-1 inline-block">
                      {v.lines?.length || 1} lines
                    </span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Right Column: Printable Official Payment Voucher Sheet */}
        <div className="lg:col-span-8 space-y-3">
          {/* Action Bar */}
          <div className="flex items-center justify-between no-print bg-white p-3 rounded-lg border border-slate-200">
            <span className="text-xs font-semibold text-slate-600">
              Voucher Preview: <strong className="text-slate-900">{activeVoucher?.pv}</strong>
            </span>
            <div className="flex items-center gap-2">
              <button
                onClick={handlePrint}
                className="px-3.5 py-1.5 text-xs font-bold rounded-lg bg-teal-800 hover:bg-teal-900 text-white transition flex items-center gap-1.5 shadow-sm"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>Print / Save as PDF</span>
              </button>
            </div>
          </div>

          {/* Printable Voucher Paper Card */}
          {activeVoucher ? (
            <div
              id="printable-voucher"
              className="bg-white rounded-xl shadow-md border border-slate-200 p-6 sm:p-8 space-y-6 text-slate-900 print:shadow-none print:border-none print:p-0 print-break-inside-avoid"
            >
              {/* Official Letterhead */}
              <div className="border-b-2 border-[#0b3d3a] pb-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2.5">
                    <div className="w-9 h-9 rounded bg-[#0b3d3a] text-[#d6b265] font-black text-lg flex items-center justify-center">
                      AVA
                    </div>
                    <h2 className="text-xl sm:text-2xl font-black text-[#0b3d3a] tracking-tight uppercase">
                      {settings.co?.name || 'AVA PASSENGERS TRANSPORT'}
                    </h2>
                  </div>
                  <p className="text-xs text-slate-600 mt-1">
                    {settings.co?.addr || 'P.O. Box 91977, Dubai, UAE | Phone: 00971 4 3439666'}
                  </p>
                </div>

                <div className="text-left sm:text-right bg-slate-50 sm:bg-transparent p-2.5 sm:p-0 rounded-lg">
                  <span className="text-xs font-mono font-bold uppercase tracking-wider text-teal-800 block">
                    PAYMENT VOUCHER
                  </span>
                  <div className="text-lg font-black font-mono text-[#0b3d3a] mt-0.5">
                    {activeVoucher.pv}
                  </div>
                  <div className="text-xs text-slate-600 mt-0.5 font-mono">
                    Date: {formatDate(activeVoucher.date)}
                  </div>
                </div>
              </div>

              {/* Payee and Method Summary Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 bg-slate-50/90 p-4 rounded-lg border border-slate-200 text-xs">
                <div>
                  <span className="text-slate-500 uppercase font-semibold text-[10px]">PAID TO:</span>
                  <div className="text-sm font-bold text-slate-900 mt-0.5">
                    {activeVoucher.party || '—'}
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <span className="text-slate-500 uppercase font-semibold text-[10px]">PAYMENT METHOD:</span>
                    <div className="font-semibold text-slate-900 mt-0.5">
                      {activeVoucher.pm || 'Cheque'}
                    </div>
                  </div>
                  <div>
                    <span className="text-slate-500 uppercase font-semibold text-[10px]">CHEQUE NUMBER:</span>
                    <div className="font-mono font-bold text-slate-900 mt-0.5">
                      {activeVoucher.chq || '—'}
                    </div>
                  </div>
                </div>
              </div>

              {/* Line Items Table */}
              <div className="border border-slate-200 rounded-lg overflow-hidden">
                <table className="min-w-full divide-y divide-slate-200 text-xs">
                  <thead className="bg-[#0b3d3a] text-white font-semibold">
                    <tr>
                      <th className="px-4 py-2.5 text-left">Sl.</th>
                      <th className="px-4 py-2.5 text-left">Description / Particulars</th>
                      <th className="px-4 py-2.5 text-center">Period</th>
                      <th className="px-4 py-2.5 text-center">Qty</th>
                      <th className="px-4 py-2.5 text-right">Rate (AED)</th>
                      <th className="px-4 py-2.5 text-right">Amount (AED)</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200 text-slate-800">
                    {activeVoucher.lines && activeVoucher.lines.length > 0 ? (
                      activeVoucher.lines.map((line, idx) => (
                        <tr key={idx} className="hover:bg-slate-50">
                          <td className="px-4 py-3 font-mono text-slate-400">{idx + 1}</td>
                          <td className="px-4 py-3 font-medium">{line.d}</td>
                          <td className="px-4 py-3 text-center text-slate-600 font-mono whitespace-nowrap">
                            {line.f && line.t ? `${line.f} to ${line.t}` : '—'}
                          </td>
                          <td className="px-4 py-3 text-center font-mono">{line.q || 1}</td>
                          <td className="px-4 py-3 text-right font-mono">{formatAED(line.u, false)}</td>
                          <td className="px-4 py-3 text-right font-mono font-bold">
                            {formatAED(line.a, false)}
                          </td>
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td className="px-4 py-3 font-mono text-slate-400">1</td>
                        <td className="px-4 py-3 font-medium">{activeVoucher.desc}</td>
                        <td className="px-4 py-3 text-center text-slate-600 font-mono">—</td>
                        <td className="px-4 py-3 text-center font-mono">1</td>
                        <td className="px-4 py-3 text-right font-mono">
                          {formatAED(activeVoucher.amt, false)}
                        </td>
                        <td className="px-4 py-3 text-right font-mono font-bold">
                          {formatAED(activeVoucher.amt, false)}
                        </td>
                      </tr>
                    )}
                  </tbody>
                  <tfoot className="bg-slate-50 border-t-2 border-slate-300 font-bold text-slate-900">
                    {activeVoucher.vat && activeVoucher.vat > 0 ? (
                      <>
                        <tr>
                          <td colSpan={5} className="px-4 py-2 text-right">Subtotal:</td>
                          <td className="px-4 py-2 text-right font-mono">
                            {formatAED(activeVoucher.amt - activeVoucher.vat)}
                          </td>
                        </tr>
                        <tr>
                          <td colSpan={5} className="px-4 py-2 text-right">VAT (5%):</td>
                          <td className="px-4 py-2 text-right font-mono">
                            {formatAED(activeVoucher.vat)}
                          </td>
                        </tr>
                        <tr className="border-t border-slate-300 text-sm">
                          <td colSpan={5} className="px-4 py-2.5 text-right font-black">Total Paid:</td>
                          <td className="px-4 py-2.5 text-right font-mono font-black text-[#0b3d3a]">
                            {formatAED(activeVoucher.amt)}
                          </td>
                        </tr>
                      </>
                    ) : (
                      <tr>
                        <td colSpan={5} className="px-4 py-3 text-right text-sm">Total Paid:</td>
                        <td className="px-4 py-3 text-right font-mono font-black text-sm text-[#0b3d3a]">
                          {formatAED(activeVoucher.amt)}
                        </td>
                      </tr>
                    )}
                  </tfoot>
                </table>
              </div>

              {/* Amount in Words */}
              <div className="bg-amber-50/70 border border-amber-200/80 p-3.5 rounded-lg text-xs">
                <span className="font-semibold text-amber-900 block text-[11px] uppercase">
                  AMOUNT IN WORDS:
                </span>
                <span className="font-bold text-[#0b3d3a] text-sm mt-0.5 block italic">
                  {numberToWordsAED(activeVoucher.amt)}
                </span>
              </div>

              {/* Signature Boxes */}
              <div className="grid grid-cols-4 gap-4 pt-8 text-center text-xs">
                <div className="border-t border-slate-300 pt-2">
                  <span className="font-semibold text-slate-700 block">Prepared By</span>
                  <span className="text-[11px] text-slate-400 mt-1 block">Office Staff</span>
                </div>
                <div className="border-t border-slate-300 pt-2">
                  <span className="font-semibold text-slate-700 block">Checked By</span>
                  <span className="text-[11px] text-slate-400 mt-1 block">Accountant</span>
                </div>
                <div className="border-t border-slate-300 pt-2">
                  <span className="font-semibold text-slate-700 block">Approved By</span>
                  <span className="text-[11px] text-slate-400 mt-1 block">Managing Director</span>
                </div>
                <div className="border-t border-slate-300 pt-2">
                  <span className="font-semibold text-slate-700 block">Receiver Signature</span>
                  <span className="text-[11px] text-slate-400 mt-1 block">Date &amp; Sign</span>
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-white rounded-xl p-12 text-center text-slate-400 border border-slate-200">
              Select a payment voucher on the left to preview or print.
            </div>
          )}
        </div>
      </div>

      {/* Create New Voucher Modal */}
      {isCreating && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-3xl w-full overflow-hidden">
            <div className="bg-[#0b3d3a] text-white px-5 py-4 flex items-center justify-between">
              <h3 className="font-extrabold text-base">New Official Payment Voucher</h3>
              <button
                onClick={() => setIsCreating(false)}
                className="p-1 rounded-lg text-teal-200 hover:text-white hover:bg-teal-800 transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateSubmit} className="p-5 sm:p-6 space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">Voucher No.</label>
                  <input
                    type="text"
                    required
                    value={pvNumber}
                    onChange={(e) => setPvNumber(e.target.value)}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg font-mono font-bold text-teal-900"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">Voucher Date</label>
                  <input
                    type="date"
                    required
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg font-mono"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">Payment Method</label>
                  <select
                    value={pm}
                    onChange={(e) => setPm(e.target.value)}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg font-semibold"
                  >
                    <option value="Cheque">Cheque</option>
                    <option value="Bank Transfer">Bank Transfer</option>
                    <option value="Cash">Cash</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="sm:col-span-2">
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">Payee / Paid To</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Sabir khan or BASHEER"
                    value={party}
                    onChange={(e) => setParty(e.target.value)}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg font-semibold"
                  />
                </div>

                {pm === 'Cheque' && (
                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-1">Cheque Number</label>
                    <input
                      type="text"
                      placeholder="e.g. 001858"
                      value={chq}
                      onChange={(e) => setChq(e.target.value)}
                      className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg font-mono font-bold"
                    />
                  </div>
                )}
              </div>

              {/* Line Items Table */}
              <div className="space-y-2 pt-2">
                <div className="flex items-center justify-between">
                  <label className="text-[11px] font-bold text-slate-700 uppercase">
                    Voucher Line Items
                  </label>
                  <button
                    type="button"
                    onClick={addLine}
                    className="px-2.5 py-1 text-xs font-semibold rounded bg-teal-50 hover:bg-teal-100 text-[#0b3d3a] border border-teal-200 flex items-center gap-1"
                  >
                    <Plus className="w-3.5 h-3.5" /> Add Line
                  </button>
                </div>

                <div className="space-y-2">
                  {lines.map((line, idx) => (
                    <div
                      key={idx}
                      className="p-3 rounded-lg bg-slate-50 border border-slate-200 grid grid-cols-12 gap-2 items-center"
                    >
                      <div className="col-span-12 sm:col-span-5">
                        <input
                          type="text"
                          required
                          placeholder="Line description (e.g. 14str shj - dxb)"
                          value={line.d}
                          onChange={(e) => updateLine(idx, 'd', e.target.value)}
                          className="w-full p-1.5 bg-white border border-slate-200 rounded text-xs"
                        />
                      </div>
                      <div className="col-span-6 sm:col-span-2">
                        <input
                          type="date"
                          placeholder="From"
                          value={line.f || ''}
                          onChange={(e) => updateLine(idx, 'f', e.target.value)}
                          className="w-full p-1.5 bg-white border border-slate-200 rounded text-[11px] font-mono"
                        />
                      </div>
                      <div className="col-span-6 sm:col-span-2">
                        <input
                          type="date"
                          placeholder="To"
                          value={line.t || ''}
                          onChange={(e) => updateLine(idx, 't', e.target.value)}
                          className="w-full p-1.5 bg-white border border-slate-200 rounded text-[11px] font-mono"
                        />
                      </div>
                      <div className="col-span-5 sm:col-span-1">
                        <input
                          type="number"
                          placeholder="Qty"
                          min="1"
                          value={line.q}
                          onChange={(e) => updateLine(idx, 'q', parseFloat(e.target.value) || 1)}
                          className="w-full p-1.5 bg-white border border-slate-200 rounded text-xs font-mono text-center"
                        />
                      </div>
                      <div className="col-span-6 sm:col-span-2">
                        <input
                          type="text"
                          required
                          placeholder="Rate (AED)"
                          value={line.u ? (line.u / 100).toFixed(2) : ''}
                          onChange={(e) => updateLine(idx, 'u', parseAEDToFils(e.target.value))}
                          className="w-full p-1.5 bg-white border border-slate-200 rounded text-xs font-mono text-right"
                        />
                      </div>
                      {lines.length > 1 && (
                        <div className="col-span-1 text-center">
                          <button
                            type="button"
                            onClick={() => removeLine(idx)}
                            className="text-slate-400 hover:text-rose-600 p-1"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              {/* Total & UAE VAT Checkbox */}
              <div className="bg-slate-50 p-4 rounded-lg border border-slate-200 flex flex-wrap items-center justify-between gap-4">
                <label className="flex items-center gap-2 cursor-pointer font-semibold text-xs text-slate-700">
                  <input
                    type="checkbox"
                    checked={hasVat}
                    onChange={(e) => setHasVat(e.target.checked)}
                    className="w-4 h-4 text-teal-700 rounded border-slate-300 focus:ring-teal-700"
                  />
                  <span>Add 5% UAE VAT to this voucher</span>
                </label>

                <div className="text-right">
                  <span className="text-xs text-slate-500 block">Total Voucher Amount:</span>
                  <span className="text-xl font-black font-mono text-[#0b3d3a]">
                    {formatAED(grandTotalFils)}
                  </span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2.5">
                <button
                  type="button"
                  onClick={() => setIsCreating(false)}
                  className="px-4 py-2 font-semibold text-slate-600 hover:bg-slate-100 rounded-lg transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 font-bold bg-[#0b3d3a] hover:bg-[#072725] text-white rounded-lg transition shadow-sm"
                >
                  Save &amp; Generate Voucher
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
