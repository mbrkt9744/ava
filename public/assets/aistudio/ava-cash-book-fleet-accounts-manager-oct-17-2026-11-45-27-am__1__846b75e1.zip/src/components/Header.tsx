import React from 'react';
import { Sparkles, Layers, Sliders, CheckCircle2, Cpu } from 'lucide-react';

interface HeaderProps {
  totalMockups: number;
  onOpenPaidFlow?: () => void;
  onScrollToGallery?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  totalMockups,
  onOpenPaidFlow,
  onScrollToGallery,
}) => {
  return (
    <header className="border-b border-slate-800/80 bg-slate-950/70 backdrop-blur-md sticky top-0 z-40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-400 via-orange-500 to-rose-500 flex items-center justify-center shadow-lg shadow-orange-500/20 text-slate-950 font-black text-xl">
            M
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-extrabold text-lg tracking-tight text-white">MarketMorph</span>
              <span className="text-xs px-2 py-0.5 rounded font-mono font-medium bg-amber-500/10 text-amber-300 border border-amber-500/30">
                Nano Banana 2.1
              </span>
            </div>
            <p className="text-xs text-slate-400 hidden sm:block">
              Multi-Medium Product Visualizer · Strict Identity Consistency
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {/* Consistency Engine Pill */}
          <div className="hidden md:flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs text-slate-300">
            <Cpu className="w-3.5 h-3.5 text-emerald-400" />
            <span>Consistency Engine:</span>
            <span className="text-emerald-400 font-semibold flex items-center gap-1">
              <CheckCircle2 className="w-3 h-3" /> Locked
            </span>
          </div>

          {/* Gallery Jump Button */}
          {totalMockups > 0 && (
            <button
              onClick={onScrollToGallery}
              className="px-3 py-1.5 text-xs font-semibold rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition flex items-center gap-1.5"
            >
              <Layers className="w-3.5 h-3.5 text-amber-400" />
              <span>Campaign Frames ({totalMockups})</span>
            </button>
          )}

          {/* Paid Key Switcher */}
          {onOpenPaidFlow && (
            <button
              onClick={onOpenPaidFlow}
              title="Ensure Paid Model API Key is selected for gemini-nano-banana-2.1"
              className="px-3 py-1.5 text-xs font-medium rounded-lg bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 transition flex items-center gap-1.5"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Model Settings</span>
            </button>
          )}
        </div>
      </div>
    </header>
  );
};
