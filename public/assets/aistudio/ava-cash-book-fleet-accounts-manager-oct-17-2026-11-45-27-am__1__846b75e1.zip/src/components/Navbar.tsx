import React from 'react';
import { TabId } from '../types/cashbook';
import { formatAED } from '../utils/currency';
import {
  LayoutDashboard,
  BookOpen,
  FileText,
  CreditCard,
  Scale,
  Bus,
  Users,
  BarChart3,
  Settings,
  PlusCircle,
  FileCheck,
  RefreshCw,
} from 'lucide-react';

interface NavbarProps {
  currentTab: TabId;
  onSelectTab: (tab: TabId) => void;
  bankBalance: number;
  pettyBalance: number;
  onNewTransaction: () => void;
  onNewVoucher: () => void;
  onSync?: () => void;
  isSyncing?: boolean;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentTab,
  onSelectTab,
  bankBalance,
  pettyBalance,
  onNewTransaction,
  onNewVoucher,
  onSync,
  isSyncing,
}) => {
  const tabs = [
    { id: 'dashboard' as TabId, label: 'Dashboard', icon: LayoutDashboard },
    { id: 'cashbook' as TabId, label: 'Cash Book', icon: BookOpen },
    { id: 'vouchers' as TabId, label: 'Vouchers', icon: FileText },
    { id: 'cheques' as TabId, label: 'Cheques', icon: CreditCard },
    { id: 'reconcile' as TabId, label: 'Reconcile', icon: Scale },
    { id: 'fleet' as TabId, label: 'Fleet', icon: Bus },
    { id: 'drivers' as TabId, label: 'Drivers & Payees', icon: Users },
    { id: 'reports' as TabId, label: 'Reports & VAT', icon: BarChart3 },
    { id: 'settings' as TabId, label: 'Settings', icon: Settings },
  ];

  return (
    <header className="bg-[#0b3d3a] text-white shadow-md sticky top-0 z-30 no-print">
      {/* Top Banner with Company Identity and Balances */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-2.5 flex flex-wrap items-center justify-between gap-3 border-b border-teal-800/60">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-[#d6b265] text-[#0b3d3a] font-extrabold flex items-center justify-center text-lg shadow-sm">
            AVA
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-extrabold text-base tracking-wide uppercase text-white">
                AVA Passengers Transport
              </span>
              <span className="text-[11px] px-2 py-0.5 rounded font-mono font-bold bg-[#d6b265]/20 text-[#d6b265] border border-[#d6b265]/40">
                Dubai · v3.4
              </span>
            </div>
            <p className="text-xs text-teal-200/80 hidden sm:block">
              Fleet Cash Book &amp; Voucher Management System
            </p>
          </div>
        </div>

        {/* Live Balances & Quick Action Buttons */}
        <div className="flex items-center gap-2 sm:gap-3 flex-wrap">
          <div className="flex items-center gap-2 bg-[#072725] px-3 py-1.5 rounded-lg border border-teal-800/80 text-xs">
            <span className="text-teal-300 font-medium">Bank:</span>
            <span className={`font-mono font-bold ${bankBalance >= 0 ? 'text-[#d6b265]' : 'text-rose-400'}`}>
              {formatAED(bankBalance)}
            </span>
            <span className="text-teal-700">|</span>
            <span className="text-teal-300 font-medium">Petty:</span>
            <span className={`font-mono font-bold ${pettyBalance >= 0 ? 'text-emerald-300' : 'text-rose-400'}`}>
              {formatAED(pettyBalance)}
            </span>
          </div>

          {onSync && (
            <button
              onClick={onSync}
              disabled={isSyncing}
              title="Sync with Google Sheets"
              className="p-1.5 rounded-lg bg-teal-800/60 hover:bg-teal-700/80 text-teal-200 transition"
            >
              <RefreshCw className={`w-4 h-4 ${isSyncing ? 'animate-spin text-[#d6b265]' : ''}`} />
            </button>
          )}

          <button
            onClick={onNewVoucher}
            className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-teal-800/80 hover:bg-teal-700 text-teal-100 border border-teal-600/40 transition flex items-center gap-1.5"
          >
            <FileCheck className="w-3.5 h-3.5 text-[#d6b265]" />
            <span className="hidden sm:inline">Voucher</span>
          </button>

          <button
            onClick={onNewTransaction}
            className="px-3 py-1.5 rounded-lg text-xs font-bold bg-[#d6b265] hover:bg-[#c49f50] text-[#0b3d3a] transition shadow flex items-center gap-1.5"
          >
            <PlusCircle className="w-3.5 h-3.5" />
            <span>Entry</span>
          </button>
        </div>
      </div>

      {/* Navigation Tabs Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <nav className="flex space-x-1 sm:space-x-2 overflow-x-auto py-1.5 scrollbar-none" aria-label="Tabs">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = currentTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => onSelectTab(tab.id)}
                className={`flex items-center gap-2 px-3 py-2 text-xs sm:text-sm font-semibold rounded-lg whitespace-nowrap transition-colors ${
                  isActive
                    ? 'bg-white text-[#0b3d3a] shadow-sm'
                    : 'text-teal-100/90 hover:bg-teal-900/60 hover:text-white'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-[#0b3d3a]' : 'text-teal-300'}`} />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </nav>
      </div>
    </header>
  );
};
