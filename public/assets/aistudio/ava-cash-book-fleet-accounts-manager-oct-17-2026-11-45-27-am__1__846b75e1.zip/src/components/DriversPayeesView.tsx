import React, { useState, useMemo } from 'react';
import { Settings, DriverInfo, PayeeInfo, Transaction } from '../types/cashbook';
import { formatAED } from '../utils/currency';
import { formatDate, daysUntil } from '../utils/date';
import {
  Users,
  UserCheck,
  Building,
  Plus,
  Phone,
  CreditCard,
  X,
  AlertCircle,
  FileCheck,
} from 'lucide-react';

interface DriversPayeesViewProps {
  settings: Settings;
  transactions: Transaction[];
  onSaveDriver: (driver: DriverInfo) => void;
  onSavePayee: (payee: PayeeInfo) => void;
}

export const DriversPayeesView: React.FC<DriversPayeesViewProps> = ({
  settings,
  transactions,
  onSaveDriver,
  onSavePayee,
}) => {
  const [activeTab, setActiveTab] = useState<'drivers' | 'payees'>('drivers');
  const [isEditingDriver, setIsEditingDriver] = useState<boolean>(false);
  const [isEditingPayee, setIsEditingPayee] = useState<boolean>(false);

  // Driver Form
  const [dName, setDName] = useState<string>('');
  const [dPhone, setDPhone] = useState<string>('');
  const [dEid, setDEid] = useState<string>('');
  const [dLic, setDLic] = useState<string>('');
  const [dLicExp, setDLicExp] = useState<string>('');
  const [dVisa, setDVisa] = useState<string>('');
  const [dNote, setDNote] = useState<string>('');
  const [dVeh, setDVeh] = useState<string>('');

  // Payee Form
  const [pName, setPName] = useState<string>('');
  const [pPhone, setPPhone] = useState<string>('');
  const [pTrn, setPTrn] = useState<string>('');
  const [pBank, setPBank] = useState<string>('');
  const [pNote, setPNote] = useState<string>('');

  const drivers = settings.drivers || [];
  const payees = settings.payees || [];

  // Payee spend calculation
  const payeeSpends = useMemo(() => {
    const map = new Map<string, number>();
    transactions.forEach((t) => {
      if (!t.deleted && t.type === 'out' && t.party) {
        const key = t.party.trim().toLowerCase();
        map.set(key, (map.get(key) || 0) + t.amt);
      }
    });
    return map;
  }, [transactions]);

  const handleOpenAddDriver = () => {
    setDName('');
    setDPhone('');
    setDEid('');
    setDLic('');
    setDLicExp('');
    setDVisa('');
    setDNote('');
    setDVeh(settings.veh?.[0] || '');
    setIsEditingDriver(true);
  };

  const handleOpenAddPayee = () => {
    setPName('');
    setPPhone('');
    setPTrn('');
    setPBank('');
    setPNote('');
    setIsEditingPayee(true);
  };

  const handleDriverSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!dName.trim()) return;

    onSaveDriver({
      name: dName.trim(),
      phone: dPhone.trim(),
      eid: dEid.trim(),
      lic: dLic.trim(),
      licExp: dLicExp,
      visa: dVisa,
      note: dNote.trim(),
      assignedVeh: dVeh,
    });
    setIsEditingDriver(false);
  };

  const handlePayeeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!pName.trim()) return;

    onSavePayee({
      name: pName.trim(),
      phone: pPhone.trim(),
      trn: pTrn.trim(),
      bank: pBank.trim(),
      note: pNote.trim(),
    });
    setIsEditingPayee(false);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-5 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-extrabold text-[#0b3d3a] tracking-tight">
            Drivers &amp; Subcontract Payees Register
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Maintain driver documents (Emirates ID, licence, residency visa) and subcontract transport suppliers with TRN &amp; IBAN
          </p>
        </div>

        <div className="flex items-center gap-2">
          {activeTab === 'drivers' ? (
            <button
              onClick={handleOpenAddDriver}
              className="px-4 py-2 text-xs font-bold rounded-lg bg-[#0b3d3a] hover:bg-[#072725] text-white transition flex items-center gap-1.5 shadow-sm"
            >
              <Plus className="w-3.5 h-3.5 text-[#d6b265]" />
              <span>Add Driver</span>
            </button>
          ) : (
            <button
              onClick={handleOpenAddPayee}
              className="px-4 py-2 text-xs font-bold rounded-lg bg-[#0b3d3a] hover:bg-[#072725] text-white transition flex items-center gap-1.5 shadow-sm"
            >
              <Plus className="w-3.5 h-3.5 text-[#d6b265]" />
              <span>Add Payee / Vendor</span>
            </button>
          )}
        </div>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-slate-200 space-x-4 text-xs font-bold">
        <button
          onClick={() => setActiveTab('drivers')}
          className={`pb-3 px-1 flex items-center gap-2 border-b-2 transition ${
            activeTab === 'drivers'
              ? 'border-[#0b3d3a] text-[#0b3d3a]'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <UserCheck className="w-4 h-4" />
          <span>Drivers Register ({drivers.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('payees')}
          className={`pb-3 px-1 flex items-center gap-2 border-b-2 transition ${
            activeTab === 'payees'
              ? 'border-[#0b3d3a] text-[#0b3d3a]'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Building className="w-4 h-4" />
          <span>Subcontract Payees &amp; Vendors ({payees.length})</span>
        </button>
      </div>

      {/* Drivers Tab Content */}
      {activeTab === 'drivers' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {drivers.map((d) => {
            const licDays = d.licExp ? daysUntil(d.licExp) : 999999;
            const visaDays = d.visa ? daysUntil(d.visa) : 999999;
            const isLicUrgent = licDays <= 30;
            const isVisaUrgent = visaDays <= 30;

            return (
              <div
                key={d.name}
                className="bg-white rounded-xl shadow-sm border border-slate-200 p-5 space-y-4 hover:border-teal-300 transition"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-teal-50 border border-teal-200 flex items-center justify-center text-[#0b3d3a] font-bold">
                      {d.name.slice(0, 2).toUpperCase()}
                    </div>
                    <div>
                      <h3 className="font-bold text-sm text-slate-900">{d.name}</h3>
                      <div className="text-[11px] text-slate-500 flex items-center gap-1 mt-0.5">
                        <Phone className="w-3 h-3 text-slate-400" />
                        <span>{d.phone || '—'}</span>
                      </div>
                    </div>
                  </div>

                  {d.assignedVeh && (
                    <span className="text-[10px] px-2 py-0.5 rounded font-mono font-bold bg-slate-100 text-slate-800 border border-slate-200">
                      {d.assignedVeh}
                    </span>
                  )}
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs bg-slate-50 p-2.5 rounded-lg border border-slate-100">
                  <div>
                    <span className="text-[10px] text-slate-400 block uppercase">EMIRATES ID</span>
                    <span className="font-mono text-slate-800 text-[11px]">{d.eid || '—'}</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 block uppercase">LICENCE NO</span>
                    <span className="font-mono text-slate-800 text-[11px]">{d.lic || '—'}</span>
                  </div>
                </div>

                <div className="space-y-1.5 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-500">Licence Expiry:</span>
                    <span className={`font-mono font-semibold ${isLicUrgent ? 'text-rose-700' : 'text-slate-800'}`}>
                      {d.licExp ? formatDate(d.licExp) : '—'} {d.licExp && `(${licDays}d left)`}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-500">Visa Expiry:</span>
                    <span className={`font-mono font-semibold ${isVisaUrgent ? 'text-rose-700' : 'text-slate-800'}`}>
                      {d.visa ? formatDate(d.visa) : '—'} {d.visa && `(${visaDays}d left)`}
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Payees Tab Content */}
      {activeTab === 'payees' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {payees.map((p) => {
            const totalPaidFils = payeeSpends.get(p.name.trim().toLowerCase()) || 0;
            return (
              <div
                key={p.name}
                className="bg-white rounded-xl shadow-sm border border-slate-200 p-5 space-y-4 hover:border-teal-300 transition"
              >
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <h3 className="font-bold text-sm text-slate-900">{p.name}</h3>
                    {p.phone && (
                      <div className="text-[11px] text-slate-500 flex items-center gap-1 mt-0.5">
                        <Phone className="w-3 h-3 text-slate-400" />
                        <span>{p.phone}</span>
                      </div>
                    )}
                  </div>

                  <div className="text-right">
                    <span className="text-[10px] text-slate-400 uppercase font-semibold block">TOTAL PAID</span>
                    <span className="text-xs font-mono font-bold text-[#0b3d3a]">
                      {formatAED(totalPaidFils)}
                    </span>
                  </div>
                </div>

                <div className="space-y-1.5 text-xs bg-slate-50 p-2.5 rounded-lg border border-slate-100">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-500 text-[10px] uppercase">TRN (TAX NO):</span>
                    <span className="font-mono font-medium text-slate-800">{p.trn || 'Not Registered'}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-500 text-[10px] uppercase">BANK / IBAN:</span>
                    <span className="font-mono text-[11px] text-slate-800 truncate max-w-[200px]">{p.bank || '—'}</span>
                  </div>
                </div>

                {p.note && (
                  <p className="text-xs text-slate-500 italic">
                    "{p.note}"
                  </p>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Add Driver Modal */}
      {isEditingDriver && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-md w-full p-6 space-y-4 text-xs">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="font-bold text-base text-slate-900">Add Driver Details</h3>
              <button onClick={() => setIsEditingDriver(false)} className="p-1 rounded text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleDriverSubmit} className="space-y-3">
              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">Driver Full Name</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Usman Khan"
                  value={dName}
                  onChange={(e) => setDName(e.target.value)}
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg font-semibold"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">Phone Number</label>
                  <input
                    type="text"
                    placeholder="050-XXXXXXX"
                    value={dPhone}
                    onChange={(e) => setDPhone(e.target.value)}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">Assigned Vehicle</label>
                  <select
                    value={dVeh}
                    onChange={(e) => setDVeh(e.target.value)}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg font-mono"
                  >
                    <option value="">— Unassigned —</option>
                    {(settings.veh || []).map((v) => (
                      <option key={v} value={v}>
                        {v}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">Emirates ID</label>
                <input
                  type="text"
                  placeholder="784-XXXX-XXXXXXX-X"
                  value={dEid}
                  onChange={(e) => setDEid(e.target.value)}
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg font-mono"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">Licence Number</label>
                  <input
                    type="text"
                    value={dLic}
                    onChange={(e) => setDLic(e.target.value)}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg font-mono"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">Licence Expiry</label>
                  <input
                    type="date"
                    value={dLicExp}
                    onChange={(e) => setDLicExp(e.target.value)}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">Residence Visa Expiry</label>
                <input
                  type="date"
                  value={dVisa}
                  onChange={(e) => setDVisa(e.target.value)}
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg font-mono"
                />
              </div>

              <div className="pt-3 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsEditingDriver(false)}
                  className="px-3.5 py-1.5 font-semibold text-slate-600 hover:bg-slate-100 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 font-bold bg-[#0b3d3a] text-white rounded-lg hover:bg-[#072725]"
                >
                  Save Driver
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add Payee Modal */}
      {isEditingPayee && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-md w-full p-6 space-y-4 text-xs">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="font-bold text-base text-slate-900">Add Payee / Subcontract Vendor</h3>
              <button onClick={() => setIsEditingPayee(false)} className="p-1 rounded text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handlePayeeSubmit} className="space-y-3">
              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">Payee / Company Name</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Sabir khan or Transport LLC"
                  value={pName}
                  onChange={(e) => setPName(e.target.value)}
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg font-semibold"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">Phone Number</label>
                <input
                  type="text"
                  placeholder="050-XXXXXXX"
                  value={pPhone}
                  onChange={(e) => setPPhone(e.target.value)}
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">TRN (Tax Registration Number)</label>
                <input
                  type="text"
                  placeholder="100XXXXXXXXX003"
                  value={pTrn}
                  onChange={(e) => setPTrn(e.target.value)}
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg font-mono"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">Bank Name / IBAN</label>
                <input
                  type="text"
                  placeholder="Bank name or AE000000000000000000000"
                  value={pBank}
                  onChange={(e) => setPBank(e.target.value)}
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg font-mono"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">Notes / Subcontract Agreement</label>
                <input
                  type="text"
                  placeholder="e.g. 14-seater subcontract driver"
                  value={pNote}
                  onChange={(e) => setPNote(e.target.value)}
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg"
                />
              </div>

              <div className="pt-3 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsEditingPayee(false)}
                  className="px-3.5 py-1.5 font-semibold text-slate-600 hover:bg-slate-100 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 font-bold bg-[#0b3d3a] text-white rounded-lg hover:bg-[#072725]"
                >
                  Save Payee
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
