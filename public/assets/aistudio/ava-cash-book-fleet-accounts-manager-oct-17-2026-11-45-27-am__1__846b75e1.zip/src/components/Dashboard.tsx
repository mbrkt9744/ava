import React from 'react';
import { Transaction, Settings, TabId } from '../types/cashbook';
import { formatAED } from '../utils/currency';
import { formatDate, getExpiryStatus } from '../utils/date';
import {
  TrendingUp,
  TrendingDown,
  AlertTriangle,
  Clock,
  ArrowRight,
  ShieldAlert,
  CreditCard,
  Bus,
  CheckCircle2,
  FileText,
  DollarSign,
  Wallet,
} from 'lucide-react';

interface DashboardProps {
  transactions: Transaction[];
  settings: Settings;
  onSelectTab: (tab: TabId) => void;
  onNewTransaction: () => void;
  onNewVoucher: () => void;
}

export const Dashboard: React.FC<DashboardProps> = ({
  transactions,
  settings,
  onSelectTab,
  onNewTransaction,
  onNewVoucher,
}) => {
  const activeTx = transactions.filter((t) => !t.deleted);

  // Compute Balances
  let bankIn = 0;
  let bankOut = 0;
  let pettyIn = 0;
  let pettyOut = 0;

  activeTx.forEach((t) => {
    if (t.acc === 'Bank') {
      if (t.type === 'in') bankIn += t.amt;
      else bankOut += t.amt;
    } else {
      if (t.type === 'in') pettyIn += t.amt;
      else pettyOut += t.amt;
    }
  });

  const bankOpening = settings.ob?.Bank || 0;
  const pettyOpening = settings.ob?.Petty || 0;
  const bankBalance = bankOpening + bankIn - bankOut;
  const pettyBalance = pettyOpening + pettyIn - pettyOut;
  const totalCash = bankBalance + pettyBalance;

  // Cheques to clear
  const toClearCheques = activeTx.filter(
    (t) => t.acc === 'Bank' && t.type === 'out' && t.chq && (!t.clr || t.clr.trim() === '')
  );
  const toClearTotalFils = toClearCheques.reduce((sum, t) => sum + t.amt, 0);

  // Expected Bank Statement Balance: Bank Ledger Balance + Uncleared Cheques
  const statementTargetFils = bankBalance + toClearTotalFils;

  // Current Month vs Last Month analysis
  // Current data is October 2026 (or dynamic current month)
  const allMonths = Array.from(new Set(activeTx.map((t) => t.date.slice(0, 7)))).sort();
  const currentMonth = allMonths[allMonths.length - 1] || '2026-10';
  const prevMonth = allMonths.length > 1 ? allMonths[allMonths.length - 2] : '';

  const curMonthTx = activeTx.filter((t) => t.date.startsWith(currentMonth));
  const curIncome = curMonthTx.filter((t) => t.type === 'in').reduce((s, t) => s + t.amt, 0);
  const curExpense = curMonthTx.filter((t) => t.type === 'out').reduce((s, t) => s + t.amt, 0);
  const curNet = curIncome - curExpense;

  const prevMonthTx = prevMonth ? activeTx.filter((t) => t.date.startsWith(prevMonth)) : [];
  const prevIncome = prevMonthTx.filter((t) => t.type === 'in').reduce((s, t) => s + t.amt, 0);
  const prevExpense = prevMonthTx.filter((t) => t.type === 'out').reduce((s, t) => s + t.amt, 0);
  const prevNet = prevIncome - prevExpense;

  // Vehicle alerts
  const vehicleList = settings.veh || [];
  const urgentVehicles: { plate: string; status: ReturnType<typeof getExpiryStatus> }[] = [];
  vehicleList.forEach((plate) => {
    const info = settings.vinfo[plate];
    if (info) {
      const st = getExpiryStatus(info.reg, info.ins);
      if (st.status === 'EXPIRED' || st.status === 'RENEW_SOON') {
        urgentVehicles.push({ plate, status: st });
      }
    }
  });

  // Check entries requiring vehicle (Diesel or Maintenance) without assigned vehicle
  const missingVehicleTx = activeTx.filter(
    (t) => (t.cat === 'Diesel' || t.cat === 'Maintenance') && (!t.veh || t.veh.trim() === '')
  );

  return (
    <div className="space-y-6">
      {/* Top Welcome & Summary Header */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-5 sm:p-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl sm:text-2xl font-black text-[#0b3d3a] tracking-tight">
              Business Health &amp; Liquidity Overview
            </h1>
            <span className="text-xs px-2.5 py-0.5 rounded-full font-semibold bg-emerald-100 text-emerald-800 border border-emerald-300">
              Live Verified
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            {settings.co?.name || 'AVA PASSENGERS TRANSPORT'} · Dubai Operations
          </p>
        </div>

        <div className="flex items-center gap-2.5 flex-wrap">
          <button
            onClick={() => onSelectTab('reconcile')}
            className="px-3.5 py-2 text-xs font-semibold rounded-lg bg-teal-50 hover:bg-teal-100 text-[#0b3d3a] border border-teal-200 transition flex items-center gap-1.5"
          >
            <span>Reconcile Statement</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={onNewVoucher}
            className="px-3.5 py-2 text-xs font-bold rounded-lg bg-white hover:bg-slate-50 text-slate-700 border border-slate-300 transition shadow-sm flex items-center gap-1.5"
          >
            <FileText className="w-3.5 h-3.5 text-[#d6b265]" />
            <span>New Voucher</span>
          </button>
          <button
            onClick={onNewTransaction}
            className="px-4 py-2 text-xs font-bold rounded-lg bg-[#0b3d3a] hover:bg-[#072725] text-white transition shadow-sm flex items-center gap-1.5"
          >
            <DollarSign className="w-3.5 h-3.5 text-[#d6b265]" />
            <span>Add Cash Entry</span>
          </button>
        </div>
      </div>

      {/* Account Balances Card Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Bank Ledger Balance */}
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-5 hover:border-teal-300 transition">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
            <span>BANK BOOK BALANCE</span>
            <Wallet className="w-4 h-4 text-teal-600" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-black font-mono text-[#0b3d3a]">
              {formatAED(bankBalance)}
            </span>
          </div>
          <p className="text-[11px] text-slate-500 mt-1.5">
            After all cheques written (Books balance)
          </p>
          <div className="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
            <span>Opening: {formatAED(bankOpening)}</span>
            <button
              onClick={() => onSelectTab('cashbook')}
              className="text-teal-700 font-semibold hover:underline"
            >
              Ledger &rarr;
            </button>
          </div>
        </div>

        {/* Bank Statement Target ("Bank Shows") */}
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-5 hover:border-amber-300 transition">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
            <span>BANK STATEMENT EXPECTED</span>
            <CreditCard className="w-4 h-4 text-amber-600" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-black font-mono text-amber-700">
              {formatAED(statementTargetFils)}
            </span>
          </div>
          <p className="text-[11px] text-slate-500 mt-1.5">
            Target if uncleared cheques haven't cleared yet
          </p>
          <div className="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
            <span className="text-amber-800 font-medium">
              {toClearCheques.length} cheques to clear ({formatAED(toClearTotalFils)})
            </span>
            <button
              onClick={() => onSelectTab('cheques')}
              className="text-amber-700 font-semibold hover:underline"
            >
              Clear &rarr;
            </button>
          </div>
        </div>

        {/* Petty Cash Balance */}
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-5 hover:border-emerald-300 transition">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
            <span>PETTY CASH IN HAND</span>
            <DollarSign className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-black font-mono text-emerald-800">
              {formatAED(pettyBalance)}
            </span>
          </div>
          <p className="text-[11px] text-slate-500 mt-1.5">
            Office petty cash register
          </p>
          <div className="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
            <span>Opening: {formatAED(pettyOpening)}</span>
            <button
              onClick={() => onSelectTab('cashbook')}
              className="text-emerald-700 font-semibold hover:underline"
            >
              View &rarr;
            </button>
          </div>
        </div>

        {/* Current Month Net Movement */}
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-5 hover:border-blue-300 transition">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
            <span>{currentMonth} NET MOVEMENT</span>
            {curNet >= 0 ? (
              <TrendingUp className="w-4 h-4 text-emerald-600" />
            ) : (
              <TrendingDown className="w-4 h-4 text-rose-600" />
            )}
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className={`text-2xl font-black font-mono ${curNet >= 0 ? 'text-emerald-700' : 'text-rose-700'}`}>
              {formatAED(curNet)}
            </span>
          </div>
          <p className="text-[11px] text-slate-500 mt-1.5">
            In: {formatAED(curIncome)} · Out: {formatAED(curExpense)}
          </p>
          <div className="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
            <span>Last month: {formatAED(prevNet)}</span>
            <button
              onClick={() => onSelectTab('reports')}
              className="text-blue-700 font-semibold hover:underline"
            >
              Reports &rarr;
            </button>
          </div>
        </div>
      </div>

      {/* Needs Attention Alert Section */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="bg-slate-50/80 px-5 py-3 border-b border-slate-200 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 text-amber-600" />
            <span className="font-bold text-sm text-slate-800">
              Needs Attention / Operational Checklist
            </span>
          </div>
          <span className="text-xs text-slate-500">
            {urgentVehicles.length + (toClearCheques.length > 0 ? 1 : 0) + (missingVehicleTx.length > 0 ? 1 : 0)} items pending
          </span>
        </div>

        <div className="p-5 grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* Urgent Vehicle Expiry Card */}
          <div className="p-4 rounded-lg bg-amber-50/60 border border-amber-200/80 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-amber-900 flex items-center gap-1.5">
                <Bus className="w-4 h-4 text-amber-700" /> Fleet Renewals Alert
              </span>
              <span className="text-xs px-2 py-0.5 rounded font-bold bg-amber-200/80 text-amber-900">
                {urgentVehicles.length} buses
              </span>
            </div>
            {urgentVehicles.length > 0 ? (
              <div className="space-y-1.5 mt-2 max-h-32 overflow-y-auto">
                {urgentVehicles.slice(0, 4).map((v) => (
                  <div key={v.plate} className="text-xs flex items-center justify-between bg-white/80 p-1.5 rounded border border-amber-200/50">
                    <span className="font-bold text-slate-800">{v.plate}</span>
                    <span className="text-[11px] font-semibold text-rose-700">{v.status.label}</span>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-xs text-emerald-800 flex items-center gap-1 pt-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> All fleet documents up to date!
              </p>
            )}
            <button
              onClick={() => onSelectTab('fleet')}
              className="text-xs text-amber-900 font-semibold hover:underline block pt-1"
            >
              Open Fleet Register &rarr;
            </button>
          </div>

          {/* Cheques to Clear Card */}
          <div className="p-4 rounded-lg bg-teal-50/60 border border-teal-200/80 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-teal-900 flex items-center gap-1.5">
                <CreditCard className="w-4 h-4 text-teal-700" /> Cheques Awaiting Presentation
              </span>
              <span className="text-xs px-2 py-0.5 rounded font-bold bg-teal-200/80 text-teal-900">
                {toClearCheques.length}
              </span>
            </div>
            <p className="text-xs text-slate-600 mt-1">
              Total pending bank debit:{' '}
              <strong className="text-teal-900 font-mono font-bold">
                {formatAED(toClearTotalFils)}
              </strong>
            </p>
            <p className="text-[11px] text-slate-500">
              Cheques 001845 through 001857 written in October vouchers.
            </p>
            <button
              onClick={() => onSelectTab('cheques')}
              className="text-xs text-teal-800 font-semibold hover:underline block pt-2"
            >
              Review &amp; Mark Cleared &rarr;
            </button>
          </div>

          {/* Missing Vehicle Tags or Categories */}
          <div className="p-4 rounded-lg bg-blue-50/60 border border-blue-200/80 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-blue-900 flex items-center gap-1.5">
                <AlertTriangle className="w-4 h-4 text-blue-700" /> Data Health Checks
              </span>
              <span className="text-xs px-2 py-0.5 rounded font-bold bg-blue-200/80 text-blue-900">
                {missingVehicleTx.length} items
              </span>
            </div>
            <p className="text-xs text-slate-600">
              {missingVehicleTx.length > 0
                ? `${missingVehicleTx.length} fuel/maintenance entries lack bus plate assignment.`
                : 'All transactions have required vehicle and tax categories assigned.'}
            </p>
            <button
              onClick={() => onSelectTab('cashbook')}
              className="text-xs text-blue-800 font-semibold hover:underline block pt-2"
            >
              Inspect Cash Book &rarr;
            </button>
          </div>
        </div>
      </div>

      {/* Recent Ledger Entries Table */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between">
          <div>
            <h2 className="font-bold text-base text-slate-900">Recent Transactions &amp; Vouchers</h2>
            <p className="text-xs text-slate-500">Latest activity across Bank and Petty Cash accounts</p>
          </div>
          <button
            onClick={() => onSelectTab('cashbook')}
            className="text-xs font-semibold text-teal-800 hover:text-teal-900 flex items-center gap-1"
          >
            <span>View All ({activeTx.length})</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-slate-200 text-left text-xs">
            <thead className="bg-slate-50 text-slate-600 font-semibold">
              <tr>
                <th className="px-4 py-3">Date</th>
                <th className="px-4 py-3">Ref / Voucher</th>
                <th className="px-4 py-3">Account</th>
                <th className="px-4 py-3">Description &amp; Payee</th>
                <th className="px-4 py-3">Category</th>
                <th className="px-4 py-3">Vehicle</th>
                <th className="px-4 py-3 text-right">Amount (AED)</th>
                <th className="px-4 py-3 text-center">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {activeTx.slice(0, 10).map((t) => {
                const isCleared = t.acc === 'Bank' && t.chq ? !!t.clr : true;
                return (
                  <tr key={t.uid} className="hover:bg-slate-50/80 transition-colors">
                    <td className="px-4 py-3 whitespace-nowrap font-mono text-slate-600">
                      {formatDate(t.date)}
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap">
                      {t.pv ? (
                        <span className="font-mono font-bold text-teal-800 bg-teal-50 px-2 py-0.5 rounded border border-teal-200">
                          {t.pv}
                        </span>
                      ) : (
                        <span className="font-mono text-slate-500">{t.ref || '—'}</span>
                      )}
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap">
                      <span className={`px-2 py-0.5 rounded text-[11px] font-semibold ${t.acc === 'Bank' ? 'bg-amber-50 text-amber-800 border border-amber-200' : 'bg-emerald-50 text-emerald-800 border border-emerald-200'}`}>
                        {t.acc}
                      </span>
                    </td>
                    <td className="px-4 py-3 max-w-xs truncate">
                      <div className="font-medium text-slate-900 truncate">{t.desc}</div>
                      {t.party && <div className="text-[11px] text-slate-500 truncate">{t.party}</div>}
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap">
                      <span className="text-slate-700">{t.cat || '—'}</span>
                      {t.sub && <span className="text-[11px] text-slate-400 block">{t.sub}</span>}
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap font-mono text-slate-600">
                      {t.veh || '—'}
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap text-right font-mono font-bold">
                      <span className={t.type === 'in' ? 'text-emerald-700' : 'text-slate-900'}>
                        {t.type === 'in' ? '+' : '-'}{formatAED(t.amt)}
                      </span>
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap text-center">
                      {t.chq ? (
                        <span className={`text-[10px] px-2 py-0.5 rounded font-semibold ${isCleared ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'}`}>
                          {isCleared ? `Cleared (${t.chq})` : `To clear (${t.chq})`}
                        </span>
                      ) : (
                        <span className="text-[10px] text-slate-400">Settled</span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
