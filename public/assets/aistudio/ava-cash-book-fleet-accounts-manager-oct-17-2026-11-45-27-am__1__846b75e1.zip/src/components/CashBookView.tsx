import React, { useState, useMemo } from 'react';
import { Transaction, Settings } from '../types/cashbook';
import { formatAED } from '../utils/currency';
import { formatDate } from '../utils/date';
import { exportTransactionsCSV } from '../utils/storage';
import {
  Search,
  Filter,
  Download,
  PlusCircle,
  Edit2,
  Trash2,
  FileText,
  Paperclip,
  CheckCircle2,
  Clock,
  ArrowUpDown,
} from 'lucide-react';

interface CashBookViewProps {
  transactions: Transaction[];
  settings: Settings;
  onNewTransaction: () => void;
  onEditTransaction: (tx: Transaction) => void;
  onDeleteTransaction: (uid: string) => void;
  onViewVoucher?: (voucherNo: string) => void;
}

export const CashBookView: React.FC<CashBookViewProps> = ({
  transactions,
  settings,
  onNewTransaction,
  onEditTransaction,
  onDeleteTransaction,
  onViewVoucher,
}) => {
  const [accountFilter, setAccountFilter] = useState<'All' | 'Bank' | 'Petty'>('All');
  const [typeFilter, setTypeFilter] = useState<'All' | 'in' | 'out'>('All');
  const [monthFilter, setMonthFilter] = useState<string>('All');
  const [categoryFilter, setCategoryFilter] = useState<string>('All');
  const [vehicleFilter, setVehicleFilter] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [sortAsc, setSortAsc] = useState<boolean>(false);

  // Available months
  const months = useMemo(() => {
    const set = new Set<string>();
    transactions.forEach((t) => {
      if (t.date) set.add(t.date.slice(0, 7));
    });
    return Array.from(set).sort().reverse();
  }, [transactions]);

  // Categories list
  const categoryList = useMemo(() => {
    return Object.keys(settings.cats || {});
  }, [settings.cats]);

  // Vehicles list
  const vehicleList = settings.veh || [];

  // Filtered & Sorted Transactions
  const filtered = useMemo(() => {
    return transactions
      .filter((t) => !t.deleted)
      .filter((t) => {
        if (accountFilter !== 'All' && t.acc !== accountFilter) return false;
        if (typeFilter !== 'All' && t.type !== typeFilter) return false;
        if (monthFilter !== 'All' && !t.date.startsWith(monthFilter)) return false;
        if (categoryFilter !== 'All' && t.cat !== categoryFilter) return false;
        if (vehicleFilter !== 'All' && t.veh !== vehicleFilter) return false;

        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase();
          const matchDesc = (t.desc || '').toLowerCase().includes(q);
          const matchParty = (t.party || '').toLowerCase().includes(q);
          const matchRef = (t.ref || '').toLowerCase().includes(q);
          const matchPv = (t.pv || '').toLowerCase().includes(q);
          const matchChq = (t.chq || '').toLowerCase().includes(q);
          const matchVeh = (t.veh || '').toLowerCase().includes(q);
          const matchSub = (t.sub || '').toLowerCase().includes(q);
          if (!matchDesc && !matchParty && !matchRef && !matchPv && !matchChq && !matchVeh && !matchSub) {
            return false;
          }
        }

        return true;
      })
      .sort((a, b) => {
        return sortAsc ? a.date.localeCompare(b.date) : b.date.localeCompare(a.date);
      });
  }, [
    transactions,
    accountFilter,
    typeFilter,
    monthFilter,
    categoryFilter,
    vehicleFilter,
    searchQuery,
    sortAsc,
  ]);

  // Filtered totals
  const totals = useMemo(() => {
    let moneyIn = 0;
    let moneyOut = 0;
    let vatTotal = 0;

    filtered.forEach((t) => {
      if (t.type === 'in') moneyIn += t.amt;
      else moneyOut += t.amt;
      vatTotal += t.vat || 0;
    });

    return {
      moneyIn,
      moneyOut,
      net: moneyIn - moneyOut,
      vatTotal,
      count: filtered.length,
    };
  }, [filtered]);

  return (
    <div className="space-y-4">
      {/* Top Filter and Search Bar */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-4 sm:p-5 space-y-4">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search description, payee, voucher no (PV-..), cheque #, vehicle..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-4 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-700 focus:bg-white transition"
            />
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            <button
              onClick={() => setSortAsc(!sortAsc)}
              className="px-3 py-2 text-xs font-semibold rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 transition flex items-center gap-1.5"
            >
              <ArrowUpDown className="w-3.5 h-3.5" />
              <span>{sortAsc ? 'Oldest First' : 'Newest First'}</span>
            </button>

            <button
              onClick={() => exportTransactionsCSV(transactions, settings)}
              className="px-3 py-2 text-xs font-semibold rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 transition flex items-center gap-1.5"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export CSV</span>
            </button>

            <button
              onClick={onNewTransaction}
              className="px-3.5 py-2 text-xs font-bold rounded-lg bg-[#0b3d3a] hover:bg-[#072725] text-white transition flex items-center gap-1.5 shadow-sm"
            >
              <PlusCircle className="w-3.5 h-3.5 text-[#d6b265]" />
              <span>New Entry</span>
            </button>
          </div>
        </div>

        {/* Filter Dropdowns Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-2.5 pt-2 border-t border-slate-100 text-xs">
          {/* Account Filter */}
          <div>
            <label className="block text-[11px] font-semibold text-slate-500 mb-1">Account</label>
            <select
              value={accountFilter}
              onChange={(e) => setAccountFilter(e.target.value as any)}
              className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 focus:outline-none focus:ring-1 focus:ring-teal-700"
            >
              <option value="All">All Accounts</option>
              <option value="Bank">Bank Account</option>
              <option value="Petty">Petty Cash</option>
            </select>
          </div>

          {/* Type Filter */}
          <div>
            <label className="block text-[11px] font-semibold text-slate-500 mb-1">Type</label>
            <select
              value={typeFilter}
              onChange={(e) => setTypeFilter(e.target.value as any)}
              className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 focus:outline-none focus:ring-1 focus:ring-teal-700"
            >
              <option value="All">Money In &amp; Out</option>
              <option value="in">Money In Only</option>
              <option value="out">Money Out Only</option>
            </select>
          </div>

          {/* Month Filter */}
          <div>
            <label className="block text-[11px] font-semibold text-slate-500 mb-1">Month</label>
            <select
              value={monthFilter}
              onChange={(e) => setMonthFilter(e.target.value)}
              className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 focus:outline-none focus:ring-1 focus:ring-teal-700 font-mono"
            >
              <option value="All">All Months</option>
              {months.map((m) => (
                <option key={m} value={m}>
                  {m}
                </option>
              ))}
            </select>
          </div>

          {/* Category Filter */}
          <div>
            <label className="block text-[11px] font-semibold text-slate-500 mb-1">Category</label>
            <select
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
              className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 focus:outline-none focus:ring-1 focus:ring-teal-700 truncate"
            >
              <option value="All">All Categories</option>
              {categoryList.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </div>

          {/* Vehicle Filter */}
          <div className="col-span-2 sm:col-span-1">
            <label className="block text-[11px] font-semibold text-slate-500 mb-1">Vehicle / Bus</label>
            <select
              value={vehicleFilter}
              onChange={(e) => setVehicleFilter(e.target.value)}
              className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 focus:outline-none focus:ring-1 focus:ring-teal-700 font-mono"
            >
              <option value="All">All Fleet</option>
              {vehicleList.map((v) => (
                <option key={v} value={v}>
                  {v}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Filtered Financial Metrics Strip */}
      <div className="bg-[#0b3d3a] text-white rounded-xl shadow-sm p-4 flex flex-wrap items-center justify-between gap-4 text-xs">
        <div className="flex items-center gap-2">
          <span className="font-semibold text-teal-200">Filtered Records:</span>
          <span className="font-mono font-bold bg-teal-900/80 px-2 py-0.5 rounded border border-teal-700">
            {totals.count} entries
          </span>
        </div>

        <div className="flex items-center gap-4 sm:gap-6 flex-wrap">
          <div>
            <span className="text-teal-300 mr-1.5">In:</span>
            <span className="font-mono font-bold text-emerald-300">{formatAED(totals.moneyIn)}</span>
          </div>
          <div>
            <span className="text-teal-300 mr-1.5">Out:</span>
            <span className="font-mono font-bold text-rose-300">{formatAED(totals.moneyOut)}</span>
          </div>
          <div>
            <span className="text-teal-300 mr-1.5">Net Movement:</span>
            <span className={`font-mono font-bold ${totals.net >= 0 ? 'text-[#d6b265]' : 'text-rose-400'}`}>
              {formatAED(totals.net)}
            </span>
          </div>
          <div>
            <span className="text-teal-300 mr-1.5">VAT:</span>
            <span className="font-mono font-medium text-teal-100">{formatAED(totals.vatTotal)}</span>
          </div>
        </div>
      </div>

      {/* Ledger Table */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-slate-200 text-left text-xs">
            <thead className="bg-slate-50 text-slate-600 font-semibold">
              <tr>
                <th className="px-3.5 py-3">Date</th>
                <th className="px-3 py-3">Ref / Voucher</th>
                <th className="px-3 py-3">Account</th>
                <th className="px-4 py-3">Description &amp; Payee</th>
                <th className="px-3 py-3">Category</th>
                <th className="px-3 py-3">Vehicle</th>
                <th className="px-3 py-3 text-right">VAT (5%)</th>
                <th className="px-4 py-3 text-right">Amount (AED)</th>
                <th className="px-3 py-3 text-center">Cheque</th>
                <th className="px-3 py-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={10} className="px-6 py-12 text-center text-slate-400">
                    No transactions match the selected filters or search query.
                  </td>
                </tr>
              ) : (
                filtered.map((t) => {
                  const isCleared = t.acc === 'Bank' && t.chq ? !!t.clr : true;
                  return (
                    <tr key={t.uid} className="hover:bg-slate-50/80 transition-colors group">
                      <td className="px-3.5 py-3 whitespace-nowrap font-mono text-slate-600">
                        {formatDate(t.date)}
                      </td>
                      <td className="px-3 py-3 whitespace-nowrap">
                        {t.pv ? (
                          <button
                            onClick={() => onViewVoucher && onViewVoucher(t.pv!)}
                            className="font-mono font-bold text-teal-800 bg-teal-50 hover:bg-teal-100 px-2 py-0.5 rounded border border-teal-200 transition"
                          >
                            {t.pv}
                          </button>
                        ) : (
                          <span className="font-mono text-slate-400">{t.ref || '—'}</span>
                        )}
                      </td>
                      <td className="px-3 py-3 whitespace-nowrap">
                        <span
                          className={`px-2 py-0.5 rounded text-[11px] font-semibold ${
                            t.acc === 'Bank'
                              ? 'bg-amber-50 text-amber-800 border border-amber-200'
                              : 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                          }`}
                        >
                          {t.acc}
                        </span>
                      </td>
                      <td className="px-4 py-3 max-w-xs sm:max-w-md">
                        <div className="font-medium text-slate-900 leading-snug">{t.desc}</div>
                        <div className="flex items-center gap-2 mt-0.5 text-[11px] text-slate-500">
                          {t.party && <span>Payee: <strong>{t.party}</strong></span>}
                          {t.drv && <span>· Driver: {t.drv}</span>}
                          {t.rcpt?.url && (
                            <a
                              href={t.rcpt.url}
                              target="_blank"
                              rel="noreferrer"
                              className="text-teal-700 font-semibold hover:underline flex items-center gap-0.5"
                            >
                              <Paperclip className="w-3 h-3" /> Receipt
                            </a>
                          )}
                        </div>
                      </td>
                      <td className="px-3 py-3 whitespace-nowrap">
                        <span className="font-medium text-slate-800">{t.cat || '—'}</span>
                        {t.sub && <span className="text-[11px] text-slate-400 block truncate max-w-[140px]">{t.sub}</span>}
                      </td>
                      <td className="px-3 py-3 whitespace-nowrap font-mono font-medium text-slate-700">
                        {t.veh ? (
                          <span className="bg-slate-100 px-1.5 py-0.5 rounded border border-slate-200">
                            {t.veh}
                          </span>
                        ) : (
                          '—'
                        )}
                      </td>
                      <td className="px-3 py-3 whitespace-nowrap text-right font-mono text-slate-500">
                        {t.vat ? formatAED(t.vat) : '—'}
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap text-right font-mono font-bold text-sm">
                        <span className={t.type === 'in' ? 'text-emerald-700' : 'text-slate-900'}>
                          {t.type === 'in' ? '+' : '-'}{formatAED(t.amt)}
                        </span>
                      </td>
                      <td className="px-3 py-3 whitespace-nowrap text-center">
                        {t.chq ? (
                          <span
                            className={`text-[10px] px-2 py-0.5 rounded font-semibold inline-flex items-center gap-1 ${
                              isCleared ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                            }`}
                          >
                            {isCleared ? (
                              <>
                                <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                                {t.chq}
                              </>
                            ) : (
                              <>
                                <Clock className="w-3 h-3 text-amber-600" />
                                {t.chq}
                              </>
                            )}
                          </span>
                        ) : (
                          <span className="text-slate-400">—</span>
                        )}
                      </td>
                      <td className="px-3 py-3 whitespace-nowrap text-right">
                        <div className="flex items-center justify-end gap-1 opacity-80 group-hover:opacity-100 transition">
                          <button
                            onClick={() => onEditTransaction(t)}
                            title="Edit entry"
                            className="p-1.5 rounded hover:bg-slate-100 text-slate-600 hover:text-teal-800"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => {
                              if (confirm(`Delete transaction "${t.desc}" (${formatAED(t.amt)})?`)) {
                                onDeleteTransaction(t.uid);
                              }
                            }}
                            title="Delete entry"
                            className="p-1.5 rounded hover:bg-rose-50 text-slate-400 hover:text-rose-600"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
