import React, { useState } from 'react';
import { Transaction, Settings } from '../types/cashbook';
import { formatAED, parseAEDToFils } from '../utils/currency';
import { calculateAccountBalances } from '../utils/cheques';
import {
  Scale,
  CheckCircle2,
  AlertCircle,
  Upload,
  ArrowRight,
  FileCheck,
  Check,
  Plus,
} from 'lucide-react';

interface ParsedStatementLine {
  id: string;
  date: string;
  desc: string;
  chqNo?: string;
  debitFils: number;
  creditFils: number;
  balanceFils?: number;
  matchStatus: 'MATCHED_CHEQUE' | 'ALREADY_RECORDED' | 'NEW_BANK_CHARGE' | 'NEW_INCOME' | 'MISMATCH';
  matchedTx?: Transaction;
}

interface ReconciliationViewProps {
  transactions: Transaction[];
  settings: Settings;
  onApplyMatches: (clearedCheques: { chq: string; date: string }[], newTransactions: Transaction[]) => void;
}

export const ReconciliationView: React.FC<ReconciliationViewProps> = ({
  transactions,
  settings,
  onApplyMatches,
}) => {
  const [statementText, setStatementText] = useState<string>('');
  const [parsedLines, setParsedLines] = useState<ParsedStatementLine[]>([]);
  const [appliedCount, setAppliedCount] = useState<number | null>(null);

  const balances = calculateAccountBalances(transactions, settings);

  // Sample statement snippet pre-filled button for demo convenience
  const loadSampleStatement = () => {
    const sample = `Date\tDetails\tDebit\tCredit\tBalance
2026-10-04\tCLG CHQ.DRAWN 001845\t15550.00\t\t129581.52
2026-10-04\tCLG CHQ.DRAWN 001846\t7386.00\t\t122195.52
2026-10-07\tCLG CHQ.DRAWN 001847\t20012.00\t\t102183.52
2026-10-07\tCHARGE COLLECTION-INCL. VAT BUSBNK_MAINT_FEE_CHRG\t103.95\t\t102079.57
2026-10-09\tCLG CHQ.DRAWN 001852\t10500.00\t\t91579.57
2026-10-09\tCLG CHQ.DRAWN 001853\t3150.00\t\t88429.57
2026-10-09\tCLG CHQ.DRAWN 001855\t9946.00\t\t78483.57`;
    setStatementText(sample);
  };

  const handleParse = () => {
    if (!statementText.trim()) return;

    const rawRows = statementText.split('\n').map((r) => r.trim()).filter(Boolean);
    const results: ParsedStatementLine[] = [];

    // Map existing active transactions
    const bankTx = transactions.filter((t) => !t.deleted && t.acc === 'Bank');

    rawRows.forEach((row, idx) => {
      // Skip header if contains words like date or debit
      if (idx === 0 && (row.toLowerCase().includes('date') || row.toLowerCase().includes('balance'))) {
        return;
      }

      // Split by tab, comma, or multiple spaces
      const cols = row.split(/\t|,|\s{2,}/).map((c) => c.trim());
      if (cols.length < 3) return;

      const dateStr = cols[0] || '';
      const descStr = cols[1] || '';
      let debitStr = cols[2] || '';
      let creditStr = cols[3] || '';
      let balStr = cols[4] || '';

      // Check if columns were shifted
      let debitFils = parseAEDToFils(debitStr);
      let creditFils = parseAEDToFils(creditStr);
      let balanceFils = balStr ? parseAEDToFils(balStr) : undefined;

      // Detect Cheque Number from description e.g. "Cheque 001845" or "001845"
      const chqMatch = descStr.match(/(?:chq|cheque|clg chq\.drawn|drawn)?\s*([0-9]{6})/i);
      const chqNo = chqMatch ? chqMatch[1] : undefined;

      let matchStatus: ParsedStatementLine['matchStatus'] = 'NEW_BANK_CHARGE';
      let matchedTx: Transaction | undefined;

      if (chqNo) {
        matchedTx = bankTx.find((t) => t.chq === chqNo);
        if (matchedTx) {
          if (matchedTx.clr) {
            matchStatus = 'ALREADY_RECORDED';
          } else {
            matchStatus = 'MATCHED_CHEQUE';
          }
        }
      } else {
        // Match by exact date, amount, description
        matchedTx = bankTx.find((t) => t.date === dateStr && t.amt === (debitFils || creditFils));
        if (matchedTx) {
          matchStatus = 'ALREADY_RECORDED';
        } else if (creditFils > 0) {
          matchStatus = 'NEW_INCOME';
        } else {
          matchStatus = 'NEW_BANK_CHARGE';
        }
      }

      results.push({
        id: `st-${idx}`,
        date: dateStr,
        desc: descStr,
        chqNo,
        debitFils,
        creditFils,
        balanceFils,
        matchStatus,
        matchedTx,
      });
    });

    setParsedLines(results);
    setAppliedCount(null);
  };

  const handleApplyAll = () => {
    const toClear: { chq: string; date: string }[] = [];
    const newTx: Transaction[] = [];

    parsedLines.forEach((line) => {
      if (line.matchStatus === 'MATCHED_CHEQUE' && line.chqNo) {
        toClear.push({ chq: line.chqNo, date: line.date });
      } else if (line.matchStatus === 'NEW_BANK_CHARGE') {
        newTx.push({
          uid: `bnk-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 6)}`,
          date: line.date,
          acc: 'Bank',
          type: 'out',
          amt: line.debitFils,
          vat: Math.round(line.debitFils * 5 / 105), // assume bank charges contain 5% VAT
          desc: line.desc,
          party: 'Bank',
          cat: 'Bank charges',
          sub: 'Maintenance fee',
          veh: '',
          ref: `BNK-${Math.floor(Math.random() * 9000 + 1000)}`,
          clr: line.date,
          by: 'Bank statement auto-import',
          createdAt: Date.now(),
          updatedAt: Date.now(),
          deleted: false,
        });
      } else if (line.matchStatus === 'NEW_INCOME') {
        newTx.push({
          uid: `in-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 6)}`,
          date: line.date,
          acc: 'Bank',
          type: 'in',
          amt: line.creditFils,
          vat: 0,
          desc: line.desc,
          party: 'Client Direct Inward Transfer',
          cat: 'Income',
          sub: 'ALICO Project Income',
          veh: '',
          ref: `BNK-IN-${Math.floor(Math.random() * 9000 + 1000)}`,
          clr: line.date,
          by: 'Bank statement auto-import',
          createdAt: Date.now(),
          updatedAt: Date.now(),
          deleted: false,
        });
      }
    });

    onApplyMatches(toClear, newTx);
    setAppliedCount(toClear.length + newTx.length);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-5">
        <h1 className="text-xl font-extrabold text-[#0b3d3a] tracking-tight">
          Automated Bank Statement Reconciler
        </h1>
        <p className="text-xs text-slate-500 mt-1">
          Paste your online bank statement (from online banking or Excel) to automatically match cheques,
          detect bank fees, and verify running balances.
        </p>
      </div>

      {/* Paste Box Card */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-5 space-y-4">
        <div className="flex items-center justify-between">
          <label className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
            <Upload className="w-4 h-4 text-teal-700" />
            Paste Statement Rows (Tab or Comma Delimited)
          </label>
          <button
            type="button"
            onClick={loadSampleStatement}
            className="text-xs text-teal-800 font-semibold hover:underline"
          >
            Load Sample October Statement
          </button>
        </div>

        <textarea
          rows={6}
          value={statementText}
          onChange={(e) => setStatementText(e.target.value)}
          placeholder="Paste rows here directly from your online banking statement..."
          className="w-full p-3 font-mono text-xs bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-teal-700 focus:bg-white transition"
        />

        <div className="flex items-center justify-between">
          <p className="text-[11px] text-slate-500">
            Expects columns: Date, Description, Debit (AED), Credit (AED), Balance (AED)
          </p>
          <button
            onClick={handleParse}
            disabled={!statementText.trim()}
            className="px-4 py-2 text-xs font-bold rounded-lg bg-[#0b3d3a] hover:bg-[#072725] text-white disabled:opacity-50 transition shadow-sm"
          >
            Parse &amp; Match Records
          </button>
        </div>
      </div>

      {/* Reconciliation Matches Results */}
      {parsedLines.length > 0 && (
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden space-y-4 p-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
            <div>
              <h2 className="font-bold text-base text-slate-900">
                Parsed Statement Analysis ({parsedLines.length} lines)
              </h2>
              <p className="text-xs text-slate-500">
                Matches against current ledger and pending cheques
              </p>
            </div>

            {appliedCount !== null ? (
              <div className="px-3 py-1.5 rounded-lg bg-emerald-100 text-emerald-800 font-bold text-xs flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                Successfully applied {appliedCount} reconciliations!
              </div>
            ) : (
              <button
                onClick={handleApplyAll}
                className="px-4 py-2 text-xs font-bold rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white transition shadow-sm flex items-center gap-1.5"
              >
                <Check className="w-4 h-4" />
                <span>Apply Matches &amp; Auto-Clear</span>
              </button>
            )}
          </div>

          <div className="border border-slate-200 rounded-lg overflow-hidden">
            <table className="min-w-full divide-y divide-slate-200 text-left text-xs">
              <thead className="bg-slate-50 text-slate-600 font-semibold">
                <tr>
                  <th className="px-4 py-3">Date</th>
                  <th className="px-4 py-3">Statement Description</th>
                  <th className="px-4 py-3 text-right">Debit (AED)</th>
                  <th className="px-4 py-3 text-right">Credit (AED)</th>
                  <th className="px-4 py-3 text-center">Match Status</th>
                  <th className="px-4 py-3">Action to Perform</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700">
                {parsedLines.map((line) => {
                  return (
                    <tr key={line.id} className="hover:bg-slate-50">
                      <td className="px-4 py-3 font-mono text-slate-600 whitespace-nowrap">
                        {line.date}
                      </td>
                      <td className="px-4 py-3 font-medium text-slate-900 max-w-sm">
                        {line.desc}
                        {line.chqNo && (
                          <span className="ml-2 font-mono text-teal-800 bg-teal-50 px-1.5 py-0.5 rounded border border-teal-200">
                            Chq #{line.chqNo}
                          </span>
                        )}
                      </td>
                      <td className="px-4 py-3 text-right font-mono font-bold text-rose-700 whitespace-nowrap">
                        {line.debitFils > 0 ? formatAED(line.debitFils) : '—'}
                      </td>
                      <td className="px-4 py-3 text-right font-mono font-bold text-emerald-700 whitespace-nowrap">
                        {line.creditFils > 0 ? formatAED(line.creditFils) : '—'}
                      </td>
                      <td className="px-4 py-3 text-center whitespace-nowrap">
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-semibold ${
                            line.matchStatus === 'MATCHED_CHEQUE'
                              ? 'bg-amber-100 text-amber-900 font-bold'
                              : line.matchStatus === 'ALREADY_RECORDED'
                              ? 'bg-slate-100 text-slate-600'
                              : line.matchStatus === 'NEW_BANK_CHARGE'
                              ? 'bg-blue-100 text-blue-900 font-bold'
                              : 'bg-emerald-100 text-emerald-900'
                          }`}
                        >
                          {line.matchStatus === 'MATCHED_CHEQUE'
                            ? 'Uncleared Cheque Match'
                            : line.matchStatus === 'ALREADY_RECORDED'
                            ? 'Already Reconciled'
                            : line.matchStatus === 'NEW_BANK_CHARGE'
                            ? 'New Bank Charge'
                            : 'New Inward Wire'}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-xs text-slate-600">
                        {line.matchStatus === 'MATCHED_CHEQUE' && (
                          <span className="text-amber-800 font-medium">
                            Will mark Cheque #{line.chqNo} cleared on {line.date}
                          </span>
                        )}
                        {line.matchStatus === 'NEW_BANK_CHARGE' && (
                          <span className="text-blue-800 font-medium">
                            Will add bank expense entry ({formatAED(line.debitFils)})
                          </span>
                        )}
                        {line.matchStatus === 'ALREADY_RECORDED' && (
                          <span className="text-slate-400">No action needed</span>
                        )}
                        {line.matchStatus === 'NEW_INCOME' && (
                          <span className="text-emerald-800 font-medium">
                            Will record inward deposit ({formatAED(line.creditFils)})
                          </span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
