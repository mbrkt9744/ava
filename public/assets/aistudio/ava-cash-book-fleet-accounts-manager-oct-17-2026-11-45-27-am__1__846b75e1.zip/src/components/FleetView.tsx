import React, { useState, useMemo } from 'react';
import { Settings, VehicleInfo, Transaction } from '../types/cashbook';
import { formatAED } from '../utils/currency';
import { formatDate, getExpiryStatus, daysUntil } from '../utils/date';
import {
  Bus,
  ShieldCheck,
  AlertTriangle,
  Plus,
  Search,
  Filter,
  X,
  CreditCard,
  Wrench,
  Fuel,
  FileCheck,
} from 'lucide-react';

interface FleetViewProps {
  settings: Settings;
  transactions: Transaction[];
  onSaveVehicle: (plate: string, info: VehicleInfo) => void;
}

export const FleetView: React.FC<FleetViewProps> = ({
  settings,
  transactions,
  onSaveVehicle,
}) => {
  const [filterStatus, setFilterStatus] = useState<'ALL' | 'EXPIRED' | 'RENEW_SOON' | 'OK'>('ALL');
  const [search, setSearch] = useState<string>('');
  const [selectedBus, setSelectedBus] = useState<string | null>(null);
  const [isEditing, setIsEditing] = useState<boolean>(false);

  // Edit / Add Modal Form State
  const [plate, setPlate] = useState<string>('');
  const [owner, setOwner] = useState<string>('');
  const [vtype, setVtype] = useState<string>('');
  const [model, setModel] = useState<string>('');
  const [seats, setSeats] = useState<number>(60);
  const [reg, setReg] = useState<string>('');
  const [ins, setIns] = useState<string>('');
  const [permit, setPermit] = useState<string>('');
  const [pexp, setPexp] = useState<string>('');
  const [parea, setParea] = useState<string>('');

  const vehicles = useMemo(() => {
    return (settings.veh || []).map((p) => {
      const info = settings.vinfo[p] || {
        plate: p,
        owner: 'AVA Passengers Transport',
        vtype: 'Bus',
        model: '2015',
        seats: 60,
        reg: '',
        ins: '',
      };
      const expiry = getExpiryStatus(info.reg, info.ins);
      return {
        ...info,
        expiry,
      };
    });
  }, [settings]);

  const filteredVehicles = useMemo(() => {
    return vehicles.filter((v) => {
      if (filterStatus !== 'ALL' && v.expiry.status !== filterStatus) return false;
      if (search.trim()) {
        const q = search.toLowerCase();
        if (
          !v.plate.toLowerCase().includes(q) &&
          !v.owner.toLowerCase().includes(q) &&
          !v.vtype.toLowerCase().includes(q) &&
          !v.model.toLowerCase().includes(q)
        ) {
          return false;
        }
      }
      return true;
    });
  }, [vehicles, filterStatus, search]);

  // Selected bus cost breakdown
  const busExpenses = useMemo(() => {
    if (!selectedBus) return null;
    const busTx = transactions.filter((t) => !t.deleted && t.veh === selectedBus);
    let dieselFils = 0;
    let maintFils = 0;
    let rentFils = 0;
    let permitFils = 0;
    let otherFils = 0;

    busTx.forEach((t) => {
      if (t.type === 'out') {
        if (t.cat === 'Diesel') dieselFils += t.amt;
        else if (t.cat === 'Maintenance') maintFils += t.amt;
        else if (t.cat === 'Rent' || t.cat === 'Vehicle hire (subcontract)') rentFils += t.amt;
        else if (t.cat === 'Permits') permitFils += t.amt;
        else otherFils += t.amt;
      }
    });

    const totalFils = dieselFils + maintFils + rentFils + permitFils + otherFils;
    return {
      busTx,
      dieselFils,
      maintFils,
      rentFils,
      permitFils,
      otherFils,
      totalFils,
    };
  }, [selectedBus, transactions]);

  const handleOpenAdd = () => {
    setPlate('');
    setOwner('A V A PASSENGERS TRANSPORT');
    setVtype('ASHOK LEYLAND');
    setModel('2018 (Ashok Leyland)');
    setSeats(60);
    setReg('');
    setIns('');
    setPermit('');
    setPexp('');
    setParea('Dubai');
    setIsEditing(true);
  };

  const handleOpenEdit = (v: VehicleInfo) => {
    setPlate(v.plate);
    setOwner(v.owner || '');
    setVtype(v.vtype || '');
    setModel(v.model || '');
    setSeats(v.seats || 60);
    setReg(v.reg || '');
    setIns(v.ins || '');
    setPermit(v.permit || '');
    setPexp(v.pexp || '');
    setParea(v.parea || '');
    setIsEditing(true);
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!plate.trim()) return;

    const info: VehicleInfo = {
      plate: plate.trim(),
      owner: owner.trim(),
      vtype: vtype.trim(),
      model: model.trim(),
      seats: Number(seats) || 60,
      reg,
      ins,
      permit: permit.trim(),
      pexp,
      parea: parea.trim(),
    };

    onSaveVehicle(info.plate, info);
    setIsEditing(false);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-5 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-extrabold text-[#0b3d3a] tracking-tight">
            Fleet Register &amp; Vehicle Compliance
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Official vehicle fleet register with registration, insurance, permits, and lifetime operating cost tracking
          </p>
        </div>

        <button
          onClick={handleOpenAdd}
          className="px-4 py-2 text-xs font-bold rounded-lg bg-[#0b3d3a] hover:bg-[#072725] text-white transition flex items-center gap-1.5 shadow-sm"
        >
          <Plus className="w-3.5 h-3.5 text-[#d6b265]" />
          <span>Add Vehicle</span>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2 overflow-x-auto pb-1 sm:pb-0 font-semibold">
          <button
            onClick={() => setFilterStatus('ALL')}
            className={`px-3 py-1.5 rounded-lg transition whitespace-nowrap ${
              filterStatus === 'ALL'
                ? 'bg-[#0b3d3a] text-white'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            All Buses ({vehicles.length})
          </button>
          <button
            onClick={() => setFilterStatus('EXPIRED')}
            className={`px-3 py-1.5 rounded-lg transition whitespace-nowrap ${
              filterStatus === 'EXPIRED'
                ? 'bg-rose-700 text-white'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            Expired ({vehicles.filter((v) => v.expiry.status === 'EXPIRED').length})
          </button>
          <button
            onClick={() => setFilterStatus('RENEW_SOON')}
            className={`px-3 py-1.5 rounded-lg transition whitespace-nowrap ${
              filterStatus === 'RENEW_SOON'
                ? 'bg-amber-600 text-white'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            Renew Soon ({vehicles.filter((v) => v.expiry.status === 'RENEW_SOON').length})
          </button>
          <button
            onClick={() => setFilterStatus('OK')}
            className={`px-3 py-1.5 rounded-lg transition whitespace-nowrap ${
              filterStatus === 'OK'
                ? 'bg-emerald-700 text-white'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            Valid ({vehicles.filter((v) => v.expiry.status === 'OK').length})
          </button>
        </div>

        <div className="relative w-full sm:w-64">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search plate, model, owner..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-8 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-teal-700"
          />
        </div>
      </div>

      {/* Vehicles Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredVehicles.map((v) => {
          return (
            <div
              key={v.plate}
              className="bg-white rounded-xl shadow-sm border border-slate-200 p-5 space-y-4 hover:border-teal-300 transition"
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-2.5">
                  <div className="w-10 h-10 rounded-lg bg-teal-50 border border-teal-200 flex items-center justify-center text-[#0b3d3a]">
                    <Bus className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="font-mono font-black text-sm text-[#0b3d3a] tracking-tight">
                      {v.plate}
                    </div>
                    <div className="text-[11px] text-slate-500 truncate max-w-[170px]">{v.owner}</div>
                  </div>
                </div>

                <span className={`text-[10px] px-2 py-0.5 rounded border ${v.expiry.badgeClass}`}>
                  {v.expiry.label}
                </span>
              </div>

              {/* Specs Grid */}
              <div className="grid grid-cols-2 gap-2 text-xs bg-slate-50 p-2.5 rounded-lg border border-slate-100">
                <div>
                  <span className="text-[10px] text-slate-400 font-semibold block uppercase">MODEL</span>
                  <span className="font-medium text-slate-800 text-[11px] truncate block">{v.model}</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 font-semibold block uppercase">SEATS</span>
                  <span className="font-bold text-slate-800 text-[11px]">{v.seats} Seats</span>
                </div>
              </div>

              {/* Expiries */}
              <div className="space-y-1.5 text-xs text-slate-600">
                <div className="flex items-center justify-between">
                  <span className="text-slate-500">Reg Expiry:</span>
                  <span className="font-mono font-medium">{v.reg ? formatDate(v.reg) : '—'}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-500">Ins Expiry:</span>
                  <span className="font-mono font-medium">{v.ins ? formatDate(v.ins) : '—'}</span>
                </div>
                {v.permit && (
                  <div className="flex items-center justify-between text-[11px] text-teal-800 pt-1 border-t border-slate-100">
                    <span>Permit: {v.permit}</span>
                    <span>{v.parea || 'UAE'}</span>
                  </div>
                )}
              </div>

              {/* Action Buttons */}
              <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs">
                <button
                  onClick={() => setSelectedBus(v.plate)}
                  className="text-teal-800 hover:text-teal-900 font-bold hover:underline"
                >
                  Cost Breakdown &rarr;
                </button>
                <button
                  onClick={() => handleOpenEdit(v)}
                  className="text-slate-600 hover:text-slate-900 font-semibold"
                >
                  Edit
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Selected Bus Cost Breakdown Drawer / Modal */}
      {selectedBus && busExpenses && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-2xl w-full p-6 space-y-5">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <Bus className="w-5 h-5 text-teal-700" />
                <h3 className="font-bold text-lg text-slate-900">
                  Operating Cost Analysis · <span className="font-mono text-[#0b3d3a]">{selectedBus}</span>
                </h3>
              </div>
              <button
                onClick={() => setSelectedBus(null)}
                className="p-1 rounded-lg hover:bg-slate-100 text-slate-400 hover:text-slate-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Cost Breakdown Cards */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                <span className="text-[10px] text-slate-500 font-semibold uppercase flex items-center gap-1">
                  <Fuel className="w-3 h-3 text-amber-600" /> Fuel / Diesel
                </span>
                <div className="text-base font-bold font-mono text-slate-900 mt-1">
                  {formatAED(busExpenses.dieselFils)}
                </div>
              </div>

              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                <span className="text-[10px] text-slate-500 font-semibold uppercase flex items-center gap-1">
                  <Wrench className="w-3 h-3 text-blue-600" /> Maintenance
                </span>
                <div className="text-base font-bold font-mono text-slate-900 mt-1">
                  {formatAED(busExpenses.maintFils)}
                </div>
              </div>

              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                <span className="text-[10px] text-slate-500 font-semibold uppercase flex items-center gap-1">
                  <CreditCard className="w-3 h-3 text-purple-600" /> Subcontract / Hire
                </span>
                <div className="text-base font-bold font-mono text-slate-900 mt-1">
                  {formatAED(busExpenses.rentFils)}
                </div>
              </div>

              <div className="p-3 bg-teal-50 rounded-lg border border-teal-200">
                <span className="text-[10px] text-teal-800 font-bold uppercase">
                  TOTAL RECORDED
                </span>
                <div className="text-base font-black font-mono text-[#0b3d3a] mt-1">
                  {formatAED(busExpenses.totalFils)}
                </div>
              </div>
            </div>

            {/* Transaction List */}
            <div className="space-y-2">
              <span className="font-bold text-xs text-slate-800 block">
                Recorded Transactions ({busExpenses.busTx.length})
              </span>
              <div className="max-h-60 overflow-y-auto border border-slate-200 rounded-lg divide-y divide-slate-100 text-xs">
                {busExpenses.busTx.length === 0 ? (
                  <div className="p-4 text-center text-slate-400">
                    No individual expense entries recorded under this vehicle plate yet.
                  </div>
                ) : (
                  busExpenses.busTx.map((t) => (
                    <div key={t.uid} className="p-2.5 flex items-center justify-between">
                      <div>
                        <div className="font-medium text-slate-900">{t.desc}</div>
                        <div className="text-[11px] text-slate-400 font-mono">
                          {formatDate(t.date)} · {t.cat} {t.party ? `· ${t.party}` : ''}
                        </div>
                      </div>
                      <div className="font-mono font-bold text-slate-900">
                        {formatAED(t.amt)}
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>

            <div className="text-right pt-2">
              <button
                onClick={() => setSelectedBus(null)}
                className="px-4 py-2 text-xs font-semibold bg-slate-100 hover:bg-slate-200 rounded-lg text-slate-800"
              >
                Close Inspector
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Edit / Add Modal */}
      {isEditing && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-lg w-full p-6 space-y-4 text-xs">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="font-bold text-base text-slate-900">Vehicle Specification</h3>
              <button onClick={() => setIsEditing(false)} className="p-1 rounded text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleFormSubmit} className="space-y-3">
              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">Plate / Bus Number</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. 27804 (SHARJAH)"
                  value={plate}
                  onChange={(e) => setPlate(e.target.value)}
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg font-mono font-bold"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">Vehicle Owner</label>
                  <input
                    type="text"
                    value={owner}
                    onChange={(e) => setOwner(e.target.value)}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">Vehicle Type</label>
                  <input
                    type="text"
                    value={vtype}
                    onChange={(e) => setVtype(e.target.value)}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">Model &amp; Year</label>
                  <input
                    type="text"
                    value={model}
                    onChange={(e) => setModel(e.target.value)}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">Seat Capacity</label>
                  <input
                    type="number"
                    value={seats}
                    onChange={(e) => setSeats(parseInt(e.target.value, 10) || 60)}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">Registration Expiry</label>
                  <input
                    type="date"
                    value={reg}
                    onChange={(e) => setReg(e.target.value)}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg font-mono"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">Insurance Expiry</label>
                  <input
                    type="date"
                    value={ins}
                    onChange={(e) => setIns(e.target.value)}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2 pt-1">
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">Permit No</label>
                  <input
                    type="text"
                    value={permit}
                    onChange={(e) => setPermit(e.target.value)}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg font-mono"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">Permit Expiry</label>
                  <input
                    type="date"
                    value={pexp}
                    onChange={(e) => setPexp(e.target.value)}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg font-mono"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">Permit Area</label>
                  <input
                    type="text"
                    value={parea}
                    onChange={(e) => setParea(e.target.value)}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg"
                  />
                </div>
              </div>

              <div className="pt-3 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsEditing(false)}
                  className="px-3.5 py-1.5 font-semibold text-slate-600 hover:bg-slate-100 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 font-bold bg-[#0b3d3a] text-white rounded-lg hover:bg-[#072725]"
                >
                  Save Vehicle
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
