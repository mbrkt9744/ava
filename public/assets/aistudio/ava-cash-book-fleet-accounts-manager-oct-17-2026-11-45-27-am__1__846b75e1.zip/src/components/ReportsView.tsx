import React, { useMemo, useState } from 'react';
import { Transaction, Settings } from '../types/cashbook';
import { formatAED } from '../utils/currency';
import { exportTransactionsCSV } from '../utils/storage';
import {
  BarChart3,
  Download,
  Printer,
  FileCheck,
  TrendingUp,
  TrendingDown,
  Info,
  DollarSign,
  Bus,
} from 'lucide-react';

interface ReportsViewProps {
  transactions: Transaction[];
  settings: Settings;
}

export const ReportsView: React.FC<ReportsViewProps> = ({ transactions, settings }) => {
  const [selectedYear, setSelectedYear] = useState<string>('2026');

  const activeTx = transactions.filter((t) => !t.deleted);

  // Monthly summary aggregation (identical math to Code.gs rebuildSummary)
  const monthlySummary = useMemo(() => {
    const map: Record<
      string,
      {
        bi: number;
        bo: number;
        pi: number;
        po: number;
        ti: number;
        to: number;
        vi: number;
        vo: number;
      }
    > = {};

    activeTx.forEach((t) => {
      const k = t.date.slice(0, 7);
      if (!map[k]) {
        map[k] = { bi: 0, bo: 0, pi: 0, po: 0, ti: 0, to: 0, vi: 0, vo: 0 };
      }
      const s = map[k];
      const pre = t.acc === 'Bank' ? 'b' : 'p';

      if (t.type === 'in') {
        s[`${pre}i` as 'bi' | 'pi'] += t.amt;
      } else {
        s[`${pre}o` as 'bo' | 'po'] += t.amt;
      }

      if (!t.tr) {
        if (t.type === 'in') {
          s.ti += t.amt;
          s.vi += t.vat || 0;
        } else {
          s.to += t.amt;
          s.vo += t.vat || 0;
        }
      }
    });

    return Object.keys(map)
      .sort()
      .map((month) => {
        const s = map[month];
        return {
          month,
          ...s,
          net: s.ti - s.to,
          vatDiff: s.vi - s.vo,
        };
      });
  }, [activeTx]);

  // Total Year VAT
  const vatSummary = useMemo(() => {
    let incomeTaxable = 0;
    let vatCollected = 0;
    let expenseTaxable = 0;
    let vatPaid = 0;

    activeTx.forEach((t) => {
      if (t.type === 'in') {
        incomeTaxable += t.amt;
        vatCollected += t.vat || 0;
      } else {
        expenseTaxable += t.amt;
        vatPaid += t.vat || 0;
      }
    });

    const netVatPosition = vatCollected - vatPaid;
    return {
      incomeTaxable,
      vatCollected,
      expenseTaxable,
      vatPaid,
      netVatPosition,
    };
  }, [activeTx]);

  // Vehicle Profitability / Cost Breakdown
  const vehicleStats = useMemo(() => {
    const stats: Record<string, { income: number; expense: number }> = {};
    (settings.veh || []).forEach((p) => {
      stats[p] = { income: 0, expense: 0 };
    });

    activeTx.forEach((t) => {
      if (t.veh && stats[t.veh]) {
        if (t.type === 'in') stats[t.veh].income += t.amt;
        else stats[t.veh].expense += t.amt;
      }
    });

    return Object.entries(stats).map(([plate, data]) => ({
      plate,
      ...data,
      net: data.income - data.expense,
    }));
  }, [activeTx, settings.veh]);

  // Category breakdown
  const categoryStats = useMemo(() => {
    const map: Record<string, number> = {};
    activeTx.forEach((t) => {
      if (!t.tr && t.type === 'out') {
        const cat = t.cat || 'Uncategorised';
        map[cat] = (map[cat] || 0) + t.amt;
      }
    });
    return Object.entries(map).sort((a, b) => b[1] - a[1]);
  }, [activeTx]);

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-5 flex flex-wrap items-center justify-between gap-4 no-print">
        <div>
          <h1 className="text-xl font-extrabold text-[#0b3d3a] tracking-tight">
            Financial Performance &amp; UAE VAT Returns
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Cash movement, 5% UAE VAT position, and fleet profitability breakdown
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => exportTransactionsCSV(transactions, settings)}
            className="px-3.5 py-2 text-xs font-semibold rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 transition flex items-center gap-1.5"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export CSV</span>
          </button>
          <button
            onClick={handlePrint}
            className="px-3.5 py-2 text-xs font-bold rounded-lg bg-[#0b3d3a] hover:bg-[#072725] text-white transition flex items-center gap-1.5 shadow-sm"
          >
            <Printer className="w-3.5 h-3.5 text-[#d6b265]" />
            <span>Print Report</span>
          </button>
        </div>
      </div>

      {/* UAE 5% VAT Return Box (FTA Compliant Layout) */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-5 sm:p-6 space-y-4">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded bg-[#d6b265] text-[#0b3d3a] font-black flex items-center justify-center text-xs">
              VAT
            </div>
            <div>
              <h2 className="font-extrabold text-sm text-slate-900">
                UAE 5% VAT Position (Federal Tax Authority Summary)
              </h2>
              <p className="text-[11px] text-slate-500">
                Calculated on actual recorded inflows and tax invoices
              </p>
            </div>
          </div>
          <span className="text-xs font-mono font-bold bg-amber-50 text-amber-800 border border-amber-200 px-2 py-0.5 rounded">
            Provisional Cash Basis
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
          {/* Output VAT */}
          <div className="p-4 bg-slate-50 rounded-lg border border-slate-200 space-y-1">
            <span className="text-[10px] text-slate-500 uppercase font-semibold block">
              BOX 1: OUTPUT VAT (COLLECTED)
            </span>
            <div className="text-xl font-black font-mono text-emerald-700">
              {formatAED(vatSummary.vatCollected)}
            </div>
            <p className="text-[11px] text-slate-400">
              Taxable Supplies: {formatAED(vatSummary.incomeTaxable)}
            </p>
          </div>

          {/* Input VAT */}
          <div className="p-4 bg-slate-50 rounded-lg border border-slate-200 space-y-1">
            <span className="text-[10px] text-slate-500 uppercase font-semibold block">
              BOX 9: INPUT VAT (PAID ON PURCHASES)
            </span>
            <div className="text-xl font-black font-mono text-rose-700">
              {formatAED(vatSummary.vatPaid)}
            </div>
            <p className="text-[11px] text-slate-400">
              Taxable Purchases: {formatAED(vatSummary.expenseTaxable)}
            </p>
          </div>

          {/* Net Position */}
          <div className="p-4 bg-teal-50 rounded-lg border border-teal-200 space-y-1">
            <span className="text-[10px] text-teal-800 uppercase font-bold block">
              NET VAT POSITION (PAYABLE / REFUNDABLE)
            </span>
            <div className={`text-xl font-black font-mono ${vatSummary.netVatPosition >= 0 ? 'text-[#0b3d3a]' : 'text-emerald-700'}`}>
              {formatAED(Math.abs(vatSummary.netVatPosition))}
            </div>
            <p className="text-[11px] text-teal-700 font-semibold">
              {vatSummary.netVatPosition >= 0 ? 'Payable to FTA' : 'Refundable from FTA'}
            </p>
          </div>
        </div>

        <div className="bg-amber-50/60 p-3 rounded-lg border border-amber-200/80 text-[11px] text-amber-900 flex items-start gap-2">
          <Info className="w-4 h-4 shrink-0 text-amber-700 mt-0.5" />
          <span>
            <strong>Accounting note:</strong> This VAT summary reflects payments and receipts recorded in the cash book.
            A formal VAT 201 return requires accrual matching of tax invoices, TRN validity verification, and FTA input tax eligibility.
          </span>
        </div>
      </div>

      {/* Monthly Summary Ledger Table */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="p-5 border-b border-slate-200 flex items-center justify-between">
          <h2 className="font-extrabold text-sm text-slate-900">
            Monthly Cash Movement &amp; Bank Summaries
          </h2>
          <span className="text-xs text-slate-500 font-mono">Reconciled to Code.gs</span>
        </div>

        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-slate-200 text-left text-xs">
            <thead className="bg-[#0b3d3a] text-white font-semibold">
              <tr>
                <th className="px-4 py-3">Month</th>
                <th className="px-4 py-3 text-right">Bank In</th>
                <th className="px-4 py-3 text-right">Bank Out</th>
                <th className="px-4 py-3 text-right">Petty In</th>
                <th className="px-4 py-3 text-right">Petty Out</th>
                <th className="px-4 py-3 text-right">Total Income</th>
                <th className="px-4 py-3 text-right">Total Expenses</th>
                <th className="px-4 py-3 text-right">Net Cash Flow</th>
                <th className="px-4 py-3 text-right">VAT Diff</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-800">
              {monthlySummary.map((m) => (
                <tr key={m.month} className="hover:bg-slate-50">
                  <td className="px-4 py-3 font-mono font-bold text-slate-900 whitespace-nowrap">
                    {m.month}
                  </td>
                  <td className="px-4 py-3 text-right font-mono text-slate-600">
                    {formatAED(m.bi, false)}
                  </td>
                  <td className="px-4 py-3 text-right font-mono text-slate-600">
                    {formatAED(m.bo, false)}
                  </td>
                  <td className="px-4 py-3 text-right font-mono text-slate-600">
                    {formatAED(m.pi, false)}
                  </td>
                  <td className="px-4 py-3 text-right font-mono text-slate-600">
                    {formatAED(m.po, false)}
                  </td>
                  <td className="px-4 py-3 text-right font-mono font-bold text-emerald-700">
                    {formatAED(m.ti, false)}
                  </td>
                  <td className="px-4 py-3 text-right font-mono font-bold text-rose-700">
                    {formatAED(m.to, false)}
                  </td>
                  <td className={`px-4 py-3 text-right font-mono font-black ${m.net >= 0 ? 'text-[#0b3d3a]' : 'text-rose-700'}`}>
                    {formatAED(m.net)}
                  </td>
                  <td className="px-4 py-3 text-right font-mono text-slate-500">
                    {formatAED(m.vatDiff)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Grid: Category Breakdown (Left) & Cost per Vehicle (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Category Breakdown */}
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-5 space-y-4">
          <h2 className="font-extrabold text-sm text-slate-900">Expenses by Category</h2>
          <div className="space-y-3">
            {categoryStats.map(([category, amount]) => {
              const totalExpenses = vatSummary.expenseTaxable || 1;
              const percent = Math.min(100, Math.round((amount / totalExpenses) * 100));
              return (
                <div key={category} className="space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold text-slate-800">{category}</span>
                    <span className="font-mono font-bold text-slate-900">
                      {formatAED(amount)} ({percent}%)
                    </span>
                  </div>
                  <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-[#0b3d3a] rounded-full"
                      style={{ width: `${percent}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Vehicle Profitability / Cost Table */}
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-5 space-y-4">
          <h2 className="font-extrabold text-sm text-slate-900">Recorded Costs per Vehicle</h2>
          <div className="border border-slate-200 rounded-lg overflow-hidden max-h-96 overflow-y-auto">
            <table className="min-w-full divide-y divide-slate-200 text-xs text-left">
              <thead className="bg-slate-50 text-slate-600 font-semibold">
                <tr>
                  <th className="px-3.5 py-2.5">Plate No.</th>
                  <th className="px-3.5 py-2.5 text-right">Income</th>
                  <th className="px-3.5 py-2.5 text-right">Cost</th>
                  <th className="px-3.5 py-2.5 text-right">Net</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {vehicleStats.map((v) => (
                  <tr key={v.plate} className="hover:bg-slate-50">
                    <td className="px-3.5 py-2 font-mono font-bold text-slate-900">{v.plate}</td>
                    <td className="px-3.5 py-2 text-right font-mono text-emerald-700">
                      {v.income > 0 ? formatAED(v.income) : '—'}
                    </td>
                    <td className="px-3.5 py-2 text-right font-mono text-rose-700">
                      {v.expense > 0 ? formatAED(v.expense) : '—'}
                    </td>
                    <td className="px-3.5 py-2 text-right font-mono font-bold text-slate-900">
                      {formatAED(v.net)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
