import React, { useState, useEffect } from 'react';
import { Transaction, Settings } from '../types/cashbook';
import { formatAED, parseAEDToFils, calculateVAT } from '../utils/currency';
import { todayUAE } from '../utils/date';
import { X, DollarSign, Camera, AlertCircle, Check } from 'lucide-react';

interface TransactionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (tx: Partial<Transaction>) => void;
  initialTx?: Transaction | null;
  settings: Settings;
  historicalDescriptions?: string[];
}

export const TransactionModal: React.FC<TransactionModalProps> = ({
  isOpen,
  onClose,
  onSave,
  initialTx,
  settings,
  historicalDescriptions = [],
}) => {
  const [date, setDate] = useState<string>(todayUAE());
  const [acc, setAcc] = useState<'Bank' | 'Petty'>('Bank');
  const [type, setType] = useState<'in' | 'out'>('out');
  const [amountStr, setAmountStr] = useState<string>('');
  const [vatMode, setVatMode] = useState<'none' | 'included' | 'added'>('none');
  const [desc, setDesc] = useState<string>('');
  const [party, setParty] = useState<string>('');
  const [cat, setCat] = useState<string>('');
  const [sub, setSub] = useState<string>('');
  const [veh, setVeh] = useState<string>('');
  const [drv, setDrv] = useState<string>('');
  const [chq, setChq] = useState<string>('');
  const [receiptUrl, setReceiptUrl] = useState<string>('');
  const [validationError, setValidationError] = useState<string>('');

  useEffect(() => {
    if (initialTx) {
      setDate(initialTx.date);
      setAcc(initialTx.acc);
      setType(initialTx.type);
      setAmountStr((initialTx.amt / 100).toFixed(2));
      setDesc(initialTx.desc || '');
      setParty(initialTx.party || '');
      setCat(initialTx.cat || '');
      setSub(initialTx.sub || '');
      setVeh(initialTx.veh || '');
      setDrv(initialTx.drv || '');
      setChq(initialTx.chq || '');
      setReceiptUrl(initialTx.rcpt?.url || initialTx.rcpt?.dataUrl || '');

      if (initialTx.vat && initialTx.vat > 0) {
        setVatMode('included');
      } else {
        setVatMode('none');
      }
    } else {
      setDate(todayUAE());
      setAcc('Bank');
      setType('out');
      setAmountStr('');
      setVatMode('none');
      setDesc('');
      setParty('');
      setCat('Vehicle hire (subcontract)');
      setSub('Bus hire');
      setVeh('');
      setDrv('');
      setChq('');
      setReceiptUrl('');
    }
    setValidationError('');
  }, [initialTx, isOpen]);

  if (!isOpen) return null;

  const currentFils = parseAEDToFils(amountStr);
  const vatCalc = calculateVAT(currentFils, vatMode);

  // Available sub-categories for currently selected category
  const subCategories = (settings.cats && cat ? settings.cats[cat] : []) || [];

  const handleReceiptFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        setReceiptUrl(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setValidationError('');

    if (currentFils <= 0) {
      setValidationError('Please enter a valid amount greater than 0 AED.');
      return;
    }

    if (!desc.trim()) {
      setValidationError('Please enter a description for this entry.');
      return;
    }

    // Vehicle check for Diesel and Maintenance
    if ((cat === 'Diesel' || cat === 'Maintenance') && !veh) {
      setValidationError(`Vehicle selection is required for category "${cat}".`);
      return;
    }

    const savedTx: Partial<Transaction> = {
      ...(initialTx || {}),
      date,
      acc,
      type,
      amt: vatCalc.total,
      vat: vatCalc.vat,
      desc: desc.trim(),
      party: party.trim(),
      cat,
      sub,
      veh,
      drv,
      chq: acc === 'Bank' && type === 'out' ? chq.trim() : '',
      rcpt: receiptUrl ? { url: receiptUrl, dataUrl: receiptUrl } : null,
      updatedAt: Date.now(),
    };

    if (!initialTx) {
      savedTx.uid = `av-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
      savedTx.createdAt = Date.now();
      savedTx.deleted = false;
      savedTx.ref = chq ? `CHQ-${chq}` : `TX-${date.replace(/-/g, '')}-${Math.floor(Math.random() * 900 + 100)}`;
    }

    onSave(savedTx);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-xl w-full overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="bg-[#0b3d3a] text-white px-5 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <DollarSign className="w-5 h-5 text-[#d6b265]" />
            <h3 className="font-extrabold text-base tracking-tight">
              {initialTx ? 'Edit Cash Book Entry' : 'Record New Transaction'}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-teal-200 hover:text-white hover:bg-teal-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-5 sm:p-6 space-y-4 text-xs">
          {validationError && (
            <div className="p-3 rounded-lg bg-rose-50 border border-rose-200 text-rose-800 flex items-center gap-2 text-xs">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
              <span>{validationError}</span>
            </div>
          )}

          {/* Account & Type Switcher */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">Account</label>
              <div className="grid grid-cols-2 gap-1 p-1 bg-slate-100 rounded-lg">
                <button
                  type="button"
                  onClick={() => setAcc('Bank')}
                  className={`py-1.5 rounded-md font-semibold transition ${
                    acc === 'Bank' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Bank Account
                </button>
                <button
                  type="button"
                  onClick={() => setAcc('Petty')}
                  className={`py-1.5 rounded-md font-semibold transition ${
                    acc === 'Petty' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Petty Cash
                </button>
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">Direction</label>
              <div className="grid grid-cols-2 gap-1 p-1 bg-slate-100 rounded-lg">
                <button
                  type="button"
                  onClick={() => setType('out')}
                  className={`py-1.5 rounded-md font-semibold transition ${
                    type === 'out' ? 'bg-rose-600 text-white shadow-sm' : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Money Out
                </button>
                <button
                  type="button"
                  onClick={() => setType('in')}
                  className={`py-1.5 rounded-md font-semibold transition ${
                    type === 'in' ? 'bg-emerald-600 text-white shadow-sm' : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Money In
                </button>
              </div>
            </div>
          </div>

          {/* Date & Amount */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">Transaction Date</label>
              <input
                type="date"
                required
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg font-mono focus:ring-1 focus:ring-teal-700"
              />
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">Amount (AED)</label>
              <div className="relative">
                <input
                  type="text"
                  required
                  placeholder="e.g. 1500.00"
                  value={amountStr}
                  onChange={(e) => setAmountStr(e.target.value)}
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg font-mono font-bold text-slate-900 focus:ring-1 focus:ring-teal-700"
                />
              </div>
            </div>
          </div>

          {/* VAT Treatment (UAE 5% Standard) */}
          <div className="bg-slate-50 p-3 rounded-lg border border-slate-200 space-y-2">
            <label className="block text-[11px] font-bold text-slate-700">UAE VAT Option (5%)</label>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => setVatMode('none')}
                className={`py-1.5 px-2 rounded-md font-medium text-[11px] transition border ${
                  vatMode === 'none'
                    ? 'bg-teal-800 text-white border-teal-800'
                    : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                }`}
              >
                No VAT (0%)
              </button>
              <button
                type="button"
                onClick={() => setVatMode('included')}
                className={`py-1.5 px-2 rounded-md font-medium text-[11px] transition border ${
                  vatMode === 'included'
                    ? 'bg-teal-800 text-white border-teal-800'
                    : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                }`}
              >
                5% Included
              </button>
              <button
                type="button"
                onClick={() => setVatMode('added')}
                className={`py-1.5 px-2 rounded-md font-medium text-[11px] transition border ${
                  vatMode === 'added'
                    ? 'bg-teal-800 text-white border-teal-800'
                    : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                }`}
              >
                Add 5% on Top
              </button>
            </div>
            {vatMode !== 'none' && currentFils > 0 && (
              <div className="text-[11px] font-mono text-slate-600 pt-1 flex items-center justify-between">
                <span>Net: {formatAED(vatCalc.net)}</span>
                <span className="text-teal-800 font-bold">VAT (5%): {formatAED(vatCalc.vat)}</span>
                <span className="font-bold text-slate-900">Total: {formatAED(vatCalc.total)}</span>
              </div>
            )}
          </div>

          {/* Description */}
          <div>
            <label className="block text-[11px] font-bold text-slate-700 mb-1">Description / Particulars</label>
            <input
              type="text"
              required
              placeholder="e.g. 14str shj - dxb or Diesel recharge or Maintenance"
              value={desc}
              onChange={(e) => setDesc(e.target.value)}
              list="desc-suggestions"
              className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg focus:ring-1 focus:ring-teal-700"
            />
            <datalist id="desc-suggestions">
              {historicalDescriptions.slice(0, 15).map((d, i) => (
                <option key={i} value={d} />
              ))}
            </datalist>
          </div>

          {/* Payee / Party & Driver */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">Paid To / Received From</label>
              <input
                type="text"
                placeholder="e.g. Sabir khan or ADNOC"
                value={party}
                onChange={(e) => setParty(e.target.value)}
                className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg focus:ring-1 focus:ring-teal-700"
              />
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">Driver (Optional)</label>
              <select
                value={drv}
                onChange={(e) => setDrv(e.target.value)}
                className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg focus:ring-1 focus:ring-teal-700"
              >
                <option value="">— No Driver Assigned —</option>
                {(settings.drivers || []).map((d) => (
                  <option key={d.name} value={d.name}>
                    {d.name} ({d.assignedVeh || 'Relief'})
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Category and Sub-category */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">Category</label>
              <select
                value={cat}
                onChange={(e) => {
                  setCat(e.target.value);
                  const firstSub = settings.cats[e.target.value]?.[0] || '';
                  setSub(firstSub);
                }}
                className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg focus:ring-1 focus:ring-teal-700"
              >
                <option value="">Select Category</option>
                {Object.keys(settings.cats || {}).map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">Sub-category</label>
              <select
                value={sub}
                onChange={(e) => setSub(e.target.value)}
                className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg focus:ring-1 focus:ring-teal-700"
              >
                <option value="">— None / General —</option>
                {subCategories.map((s) => (
                  <option key={s} value={s}>
                    {s}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Vehicle and Cheque No */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">
                Vehicle Plate{' '}
                {(cat === 'Diesel' || cat === 'Maintenance') && (
                  <span className="text-rose-600 font-bold">*Required</span>
                )}
              </label>
              <select
                value={veh}
                onChange={(e) => setVeh(e.target.value)}
                className={`w-full p-2 bg-slate-50 border rounded-lg font-mono focus:ring-1 focus:ring-teal-700 ${
                  (cat === 'Diesel' || cat === 'Maintenance') && !veh ? 'border-rose-400 bg-rose-50/50' : 'border-slate-200'
                }`}
              >
                <option value="">— No Vehicle Assigned —</option>
                {(settings.veh || []).map((v) => (
                  <option key={v} value={v}>
                    {v}
                  </option>
                ))}
              </select>
            </div>

            {acc === 'Bank' && type === 'out' && (
              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">Cheque Number</label>
                <input
                  type="text"
                  placeholder="e.g. 001858"
                  value={chq}
                  onChange={(e) => setChq(e.target.value)}
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg font-mono font-bold focus:ring-1 focus:ring-teal-700"
                />
              </div>
            )}
          </div>

          {/* Receipt Photo Capture / Upload */}
          <div>
            <label className="block text-[11px] font-bold text-slate-700 mb-1">Receipt Attachment</label>
            <div className="flex items-center gap-3">
              <label className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg cursor-pointer transition flex items-center gap-1.5 font-semibold text-xs border border-slate-200">
                <Camera className="w-3.5 h-3.5" />
                <span>Upload / Take Photo</span>
                <input
                  type="file"
                  accept="image/*,application/pdf"
                  onChange={handleReceiptFile}
                  className="hidden"
                />
              </label>
              {receiptUrl && (
                <div className="flex items-center gap-2">
                  <span className="text-emerald-700 font-semibold flex items-center gap-1">
                    <Check className="w-3.5 h-3.5" /> Attached
                  </span>
                  <button
                    type="button"
                    onClick={() => setReceiptUrl('')}
                    className="text-rose-600 hover:underline"
                  >
                    Remove
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* Buttons */}
          <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2.5">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 font-semibold text-slate-600 hover:bg-slate-100 rounded-lg transition"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 font-bold bg-[#0b3d3a] hover:bg-[#072725] text-white rounded-lg transition shadow-sm"
            >
              Save Entry
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
