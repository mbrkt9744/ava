import React, { useState, useMemo } from 'react';
import { Transaction, Settings } from '../types/cashbook';
import { analyzeCheques, calculateAccountBalances } from '../utils/cheques';
import { formatAED } from '../utils/currency';
import { formatDate, todayUAE } from '../utils/date';
import {
  CreditCard,
  CheckCircle2,
  Clock,
  AlertOctagon,
  Ban,
  Search,
  Check,
  Calendar,
} from 'lucide-react';

interface ChequesViewProps {
  transactions: Transaction[];
  settings: Settings;
  onMarkChequeCleared: (chqNumber: string, clearDate: string) => void;
  onMarkChequeCancelled: (chqNumber: string, note: string) => void;
  onViewVoucher?: (voucherNo: string) => void;
}

export const ChequesView: React.FC<ChequesViewProps> = ({
  transactions,
  settings,
  onMarkChequeCleared,
  onMarkChequeCancelled,
  onViewVoucher,
}) => {
  const [filterTab, setFilterTab] = useState<'all' | 'to_clear' | 'cleared' | 'returned' | 'missing' | 'cancelled'>('to_clear');
  const [search, setSearch] = useState<string>('');
  const [clearingChq, setClearingChq] = useState<string | null>(null);
  const [clearDate, setClearDate] = useState<string>(todayUAE());

  const analysis = useMemo(() => {
    return analyzeCheques(transactions, settings);
  }, [transactions, settings]);

  const balances = useMemo(() => {
    return calculateAccountBalances(transactions, settings);
  }, [transactions, settings]);

  // Expected statement balance
  const expectedStatementFils = balances.bankBalance + analysis.toClearTotalFils;

  // Filtered List
  const displayedList = useMemo(() => {
    let list = analysis.allList;
    if (filterTab === 'to_clear') list = analysis.toClearList;
    else if (filterTab === 'cleared') list = analysis.clearedList;
    else if (filterTab === 'returned') list = analysis.returnedList;
    else if (filterTab === 'cancelled') list = analysis.cancelledList;
    else if (filterTab === 'missing') list = analysis.missingList;

    if (search.trim()) {
      const q = search.toLowerCase();
      list = list.filter(
        (c) =>
          c.chq.includes(q) ||
          c.payee.toLowerCase().includes(q) ||
          c.desc.toLowerCase().includes(q) ||
          (c.voucherNo || '').toLowerCase().includes(q)
      );
    }

    return list;
  }, [analysis, filterTab, search]);

  const handleConfirmClear = (chq: string) => {
    onMarkChequeCleared(chq, clearDate);
    setClearingChq(null);
  };

  const handleCancelCheque = (chq: string) => {
    const reason = prompt(`Reason for cancelling / voiding cheque leaf #${chq}?`, 'Spoiled / Cancelled leaf');
    if (reason !== null) {
      onMarkChequeCancelled(chq, reason);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-5">
        <h1 className="text-xl font-extrabold text-[#0b3d3a] tracking-tight">
          Cheque Register &amp; Bank Presentation Manager
        </h1>
        <p className="text-xs text-slate-500 mt-1">
          Track cheques written, presentation status, bank debits, returned items, and missing cheque book stubs
        </p>
      </div>

      {/* Reconciliation Math Card */}
      <div className="bg-gradient-to-br from-[#0b3d3a] to-[#072725] text-white rounded-xl shadow-sm p-5 sm:p-6 border border-teal-900">
        <div className="flex items-center justify-between border-b border-teal-800/80 pb-3 mb-4">
          <span className="text-xs font-bold tracking-wider uppercase text-teal-300">
            BANK RECONCILIATION FORMULA (TO THE FILS)
          </span>
          <span className="text-xs font-mono bg-teal-900/80 px-2 py-0.5 rounded text-[#d6b265] border border-teal-700">
            UAE Commercial Standard
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 text-center sm:text-left">
          <div className="space-y-1">
            <span className="text-xs text-teal-300">Bank Books Balance</span>
            <div className="text-2xl font-black font-mono text-white">
              {formatAED(balances.bankBalance)}
            </div>
            <p className="text-[11px] text-teal-200/70">Our ledger after cheques recorded</p>
          </div>

          <div className="space-y-1 sm:border-l sm:border-teal-800/80 sm:pl-6">
            <span className="text-xs text-[#d6b265] font-semibold">
              + Uncleared Cheques ({analysis.toClearList.length})
            </span>
            <div className="text-2xl font-black font-mono text-[#d6b265]">
              {formatAED(analysis.toClearTotalFils)}
            </div>
            <p className="text-[11px] text-teal-200/70">Written but not yet debited by bank</p>
          </div>

          <div className="space-y-1 sm:border-l sm:border-teal-800/80 sm:pl-6">
            <span className="text-xs text-emerald-300 font-semibold">= Expected Bank Statement</span>
            <div className="text-2xl font-black font-mono text-emerald-300">
              {formatAED(expectedStatementFils)}
            </div>
            <p className="text-[11px] text-teal-200/70">Balance bank statement should reflect</p>
          </div>
        </div>
      </div>

      {/* Cheques Status Tab Bar */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-4 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          {/* Status Tabs */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0 text-xs font-semibold">
            <button
              onClick={() => setFilterTab('to_clear')}
              className={`px-3 py-1.5 rounded-lg transition whitespace-nowrap flex items-center gap-1.5 ${
                filterTab === 'to_clear'
                  ? 'bg-amber-600 text-white shadow-sm'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <Clock className="w-3.5 h-3.5" />
              <span>To Clear ({analysis.toClearList.length})</span>
            </button>

            <button
              onClick={() => setFilterTab('cleared')}
              className={`px-3 py-1.5 rounded-lg transition whitespace-nowrap flex items-center gap-1.5 ${
                filterTab === 'cleared'
                  ? 'bg-emerald-700 text-white shadow-sm'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>Cleared ({analysis.clearedList.length})</span>
            </button>

            <button
              onClick={() => setFilterTab('returned')}
              className={`px-3 py-1.5 rounded-lg transition whitespace-nowrap flex items-center gap-1.5 ${
                filterTab === 'returned'
                  ? 'bg-rose-600 text-white shadow-sm'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <AlertOctagon className="w-3.5 h-3.5" />
              <span>Returned ({analysis.returnedList.length})</span>
            </button>

            <button
              onClick={() => setFilterTab('missing')}
              className={`px-3 py-1.5 rounded-lg transition whitespace-nowrap flex items-center gap-1.5 ${
                filterTab === 'missing'
                  ? 'bg-rose-700 text-white shadow-sm'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <Ban className="w-3.5 h-3.5" />
              <span>Missing Numbers ({analysis.missingList.length})</span>
            </button>

            <button
              onClick={() => setFilterTab('all')}
              className={`px-3 py-1.5 rounded-lg transition whitespace-nowrap ${
                filterTab === 'all'
                  ? 'bg-[#0b3d3a] text-white shadow-sm'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              All Cheques ({analysis.allList.length})
            </button>
          </div>

          {/* Search Box */}
          <div className="relative w-full sm:w-64">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search cheque #, payee..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-8 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-teal-700"
            />
          </div>
        </div>

        {/* Table of Cheques */}
        <div className="border border-slate-200 rounded-lg overflow-hidden">
          <table className="min-w-full divide-y divide-slate-200 text-left text-xs">
            <thead className="bg-slate-50 text-slate-600 font-semibold">
              <tr>
                <th className="px-4 py-3">Cheque No.</th>
                <th className="px-4 py-3">Issue Date</th>
                <th className="px-4 py-3">Voucher</th>
                <th className="px-4 py-3">Payee / Particulars</th>
                <th className="px-4 py-3 text-right">Amount (AED)</th>
                <th className="px-4 py-3 text-center">Status</th>
                <th className="px-4 py-3">Cleared Date</th>
                <th className="px-4 py-3 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {displayedList.length === 0 ? (
                <tr>
                  <td colSpan={8} className="px-6 py-8 text-center text-slate-400">
                    No cheques found under this status filter.
                  </td>
                </tr>
              ) : (
                displayedList.map((c) => {
                  return (
                    <tr key={c.chq} className="hover:bg-slate-50/80 transition-colors">
                      <td className="px-4 py-3 whitespace-nowrap font-mono font-bold text-slate-900">
                        {c.chq}
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap font-mono text-slate-600">
                        {c.date ? formatDate(c.date) : '—'}
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap">
                        {c.voucherNo ? (
                          <button
                            onClick={() => onViewVoucher && onViewVoucher(c.voucherNo!)}
                            className="font-mono font-bold text-teal-800 bg-teal-50 hover:bg-teal-100 px-2 py-0.5 rounded border border-teal-200"
                          >
                            {c.voucherNo}
                          </button>
                        ) : (
                          '—'
                        )}
                      </td>
                      <td className="px-4 py-3 max-w-xs">
                        <div className="font-semibold text-slate-900 truncate">{c.payee}</div>
                        <div className="text-[11px] text-slate-500 truncate">{c.desc}</div>
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap text-right font-mono font-bold">
                        {c.amountFils > 0 ? formatAED(c.amountFils) : '—'}
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap text-center">
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-semibold ${
                            c.status === 'Cleared'
                              ? 'bg-emerald-100 text-emerald-800'
                              : c.status === 'To clear'
                              ? 'bg-amber-100 text-amber-800 font-bold'
                              : c.status === 'Returned'
                              ? 'bg-rose-100 text-rose-800 font-bold'
                              : c.status === 'MISSING'
                              ? 'bg-rose-200 text-rose-900 font-black'
                              : 'bg-slate-100 text-slate-600'
                          }`}
                        >
                          {c.status}
                        </span>
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap font-mono text-slate-600">
                        {c.clearedOn ? formatDate(c.clearedOn) : '—'}
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap text-right">
                        {c.status === 'To clear' && (
                          <button
                            onClick={() => setClearingChq(c.chq)}
                            className="px-2.5 py-1 text-[11px] font-bold rounded bg-teal-50 hover:bg-teal-100 text-teal-900 border border-teal-200 transition"
                          >
                            Mark Cleared
                          </button>
                        )}
                        {c.status === 'MISSING' && (
                          <button
                            onClick={() => handleCancelCheque(c.chq)}
                            className="px-2.5 py-1 text-[11px] font-semibold rounded bg-slate-100 hover:bg-slate-200 text-slate-700 transition"
                          >
                            Mark Void
                          </button>
                        )}
                        {c.status === 'Cleared' && (
                          <span className="text-[11px] text-emerald-700 flex items-center justify-end gap-1">
                            <Check className="w-3 h-3" /> Paid
                          </span>
                        )}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Clear Cheque Modal */}
      {clearingChq && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-xl border border-slate-200 max-w-sm w-full p-5 space-y-4">
            <h3 className="font-bold text-base text-slate-900">
              Clear Cheque #{clearingChq}
            </h3>
            <p className="text-xs text-slate-500">
              Confirm the date this cheque appeared as debited on your official bank statement:
            </p>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Cleared Date</label>
              <input
                type="date"
                value={clearDate}
                onChange={(e) => setClearDate(e.target.value)}
                className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg font-mono text-xs"
              />
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => setClearingChq(null)}
                className="px-3.5 py-1.5 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg"
              >
                Cancel
              </button>
              <button
                onClick={() => handleConfirmClear(clearingChq)}
                className="px-4 py-1.5 text-xs font-bold bg-[#0b3d3a] text-white rounded-lg hover:bg-[#072725]"
              >
                Confirm Cleared
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
