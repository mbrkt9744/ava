import React, { useState } from 'react';
import { Settings, CashbookData } from '../types/cashbook';
import { formatAED, parseAEDToFils } from '../utils/currency';
import { downloadBackupJSON } from '../utils/storage';
import { INITIAL_DATA } from '../data/initialData';
import {
  Settings as SettingsIcon,
  Cloud,
  Download,
  Upload,
  RefreshCw,
  Building,
  DollarSign,
  Layers,
  CheckCircle2,
  AlertCircle,
  Copy,
  Check,
  FileCode,
} from 'lucide-react';

interface SettingsViewProps {
  settings: Settings;
  onUpdateSettings: (newSettings: Settings) => void;
  fullData: CashbookData;
  onRestoreData: (restoredData: CashbookData) => void;
  onSyncNow?: () => void;
  isSyncing?: boolean;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  settings,
  onUpdateSettings,
  fullData,
  onRestoreData,
  onSyncNow,
  isSyncing,
}) => {
  const [coName, setCoName] = useState<string>(settings.co?.name || 'AVA PASSENGERS TRANSPORT');
  const [coAddr, setCoAddr] = useState<string>(
    settings.co?.addr || 'P.O. Box 91977, Dubai, UAE | Phone: 00971 4 3439666 | Email: Contact@avarental.ae'
  );

  const [bankObStr, setBankObStr] = useState<string>(((settings.ob?.Bank || 0) / 100).toFixed(2));
  const [pettyObStr, setPettyObStr] = useState<string>(((settings.ob?.Petty || 0) / 100).toFixed(2));

  // Google Connection
  const [scriptUrl, setScriptUrl] = useState<string>(settings.googleScriptUrl || '');
  const [apiKey, setApiKey] = useState<string>(settings.googleApiKey || '');
  const [device, setDevice] = useState<string>(settings.deviceName || 'Main Office');
  const [testResult, setTestResult] = useState<{ ok: boolean; msg: string } | null>(null);
  const [copiedCode, setCopiedCode] = useState<boolean>(false);

  // New Category / Subcategory
  const [newCatName, setNewCatName] = useState<string>('');
  const [selectedCatForSub, setSelectedCatForSub] = useState<string>(Object.keys(settings.cats || {})[0] || '');
  const [newSubName, setNewSubName] = useState<string>('');

  const [saveSuccess, setSaveSuccess] = useState<boolean>(false);

  const handleSaveCompanyAndBalances = (e: React.FormEvent) => {
    e.preventDefault();
    const updated: Settings = {
      ...settings,
      co: {
        name: coName.trim(),
        addr: coAddr.trim(),
      },
      ob: {
        Bank: parseAEDToFils(bankObStr),
        Petty: parseAEDToFils(pettyObStr),
      },
      googleScriptUrl: scriptUrl.trim(),
      googleApiKey: apiKey.trim(),
      deviceName: device.trim(),
      updatedAt: Date.now(),
    };

    onUpdateSettings(updated);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 3000);
  };

  const handleAddCategory = () => {
    if (!newCatName.trim()) return;
    const catName = newCatName.trim();
    if (settings.cats[catName]) {
      alert('Category already exists');
      return;
    }
    const updated = {
      ...settings,
      cats: {
        ...settings.cats,
        [catName]: [],
      },
    };
    onUpdateSettings(updated);
    setNewCatName('');
  };

  const handleAddSubcategory = () => {
    if (!selectedCatForSub || !newSubName.trim()) return;
    const currentSubs = settings.cats[selectedCatForSub] || [];
    if (currentSubs.includes(newSubName.trim())) {
      alert('Sub-category already exists');
      return;
    }
    const updated = {
      ...settings,
      cats: {
        ...settings.cats,
        [selectedCatForSub]: [...currentSubs, newSubName.trim()],
      },
    };
    onUpdateSettings(updated);
    setNewSubName('');
  };

  const handleFileRestore = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const parsed = JSON.parse(event.target?.result as string);
        if (!parsed.tx || !parsed.settings) {
          alert('Invalid backup file. Must contain "tx" and "settings" objects.');
          return;
        }
        if (confirm(`Restore ${parsed.tx.length} transactions from "${file.name}"? This will replace the active data.`)) {
          onRestoreData(parsed);
          alert('Data restored successfully!');
        }
      } catch (err: any) {
        alert('Failed to parse backup JSON: ' + err.message);
      }
    };
    reader.readAsText(file);
  };

  const handleResetToStartingData = () => {
    if (confirm('Reset to the initial 49 transactions and starting configuration?')) {
      onRestoreData(INITIAL_DATA);
    }
  };

  const testGoogleConnection = async () => {
    setTestResult(null);
    if (!scriptUrl) {
      setTestResult({ ok: false, msg: 'Please provide the Web App URL ending in /exec' });
      return;
    }

    try {
      const res = await fetch('/api/google-proxy', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          scriptUrl,
          payload: { op: 'ping', key: apiKey },
        }),
      });

      const data = await res.json();
      if (data.ok) {
        setTestResult({ ok: true, msg: `Connected successfully to Google Sheet "${data.sheet}"!` });
      } else {
        setTestResult({ ok: false, msg: `Error: ${data.error || 'Connection failed'}` });
      }
    } catch (err: any) {
      setTestResult({ ok: false, msg: `Network Error: ${err.message}` });
    }
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* Top Banner */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-5 flex items-center justify-between">
        <div>
          <h1 className="text-xl font-extrabold text-[#0b3d3a] tracking-tight">
            Settings, Google Sync &amp; Backup
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Configure company letterhead, opening balances, categories, Google Sheets connection, and JSON backups
          </p>
        </div>

        {saveSuccess && (
          <div className="px-3 py-1.5 rounded-lg bg-emerald-100 text-emerald-800 text-xs font-bold flex items-center gap-1.5 animate-in fade-in">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            Saved!
          </div>
        )}
      </div>

      {/* Form: Company Profile & Opening Balances */}
      <form onSubmit={handleSaveCompanyAndBalances} className="space-y-6">
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-5 sm:p-6 space-y-4 text-xs">
          <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
            <Building className="w-4 h-4 text-teal-800" />
            <h2 className="font-extrabold text-sm text-slate-900">
              Company Profile &amp; Payment Voucher Header
            </h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">Company Registered Name</label>
              <input
                type="text"
                required
                value={coName}
                onChange={(e) => setCoName(e.target.value)}
                className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg font-semibold"
              />
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">Device Nickname</label>
              <input
                type="text"
                value={device}
                onChange={(e) => setDevice(e.target.value)}
                placeholder="e.g. Office PC or Mobile 1"
                className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block text-[11px] font-bold text-slate-700 mb-1">Address &amp; Contact Header</label>
              <input
                type="text"
                required
                value={coAddr}
                onChange={(e) => setCoAddr(e.target.value)}
                className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg"
              />
            </div>
          </div>

          {/* Opening Balances */}
          <div className="pt-4 border-t border-slate-100">
            <label className="block text-xs font-bold text-slate-800 mb-2 uppercase">
              Opening Balances (August 1, 2026 Starting Point)
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">Bank Opening Balance (AED)</label>
                <input
                  type="text"
                  required
                  value={bankObStr}
                  onChange={(e) => setBankObStr(e.target.value)}
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg font-mono font-bold"
                />
                <span className="text-[11px] text-slate-400 mt-1 block">Original starting balance: 50,418.86 AED</span>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">Petty Cash Opening (AED)</label>
                <input
                  type="text"
                  required
                  value={pettyObStr}
                  onChange={(e) => setPettyObStr(e.target.value)}
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg font-mono font-bold"
                />
                <span className="text-[11px] text-slate-400 mt-1 block">Original starting balance: 0.00 AED</span>
              </div>
            </div>
          </div>

          {/* Google Sheets Sync Settings */}
          <div className="pt-4 border-t border-slate-100 space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-slate-800 uppercase flex items-center gap-1.5">
                <Cloud className="w-4 h-4 text-teal-700" /> Google Sheets &amp; Drive Sync Connection
              </label>
              <button
                type="button"
                onClick={testGoogleConnection}
                className="text-xs font-semibold text-teal-800 hover:underline"
              >
                Test Connection
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">Apps Script Web App URL</label>
                <input
                  type="url"
                  placeholder="https://script.google.com/macros/s/.../exec"
                  value={scriptUrl}
                  onChange={(e) => setScriptUrl(e.target.value)}
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg font-mono text-[11px]"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">Connection Key (API_KEY)</label>
                <input
                  type="text"
                  placeholder="e.g. 7F3A-91C2-..."
                  value={apiKey}
                  onChange={(e) => setApiKey(e.target.value)}
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg font-mono text-[11px]"
                />
              </div>
            </div>

            {testResult && (
              <div
                className={`p-3 rounded-lg border text-xs flex items-center gap-2 ${
                  testResult.ok
                    ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
                    : 'bg-rose-50 border-rose-200 text-rose-800'
                }`}
              >
                {testResult.ok ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                ) : (
                  <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                )}
                <span>{testResult.msg}</span>
              </div>
            )}
          </div>

          <div className="pt-2 flex justify-end">
            <button
              type="submit"
              className="px-5 py-2 text-xs font-bold bg-[#0b3d3a] hover:bg-[#072725] text-white rounded-lg shadow-sm transition"
            >
              Save Configuration
            </button>
          </div>
        </div>
      </form>

      {/* Backup, Restore & Reset Section */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-5 sm:p-6 space-y-4 text-xs">
        <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
          <Download className="w-4 h-4 text-teal-800" />
          <h2 className="font-extrabold text-sm text-slate-900">
            Database Backup &amp; Disaster Recovery
          </h2>
        </div>

        <p className="text-slate-500">
          Download a complete offline JSON snapshot of your cash book including all 49 transactions,
          fleet details, and settings. You can restore this file on any phone or computer anytime.
        </p>

        <div className="flex flex-wrap items-center gap-3 pt-2">
          <button
            onClick={() => downloadBackupJSON(fullData)}
            className="px-4 py-2 text-xs font-bold rounded-lg bg-teal-800 hover:bg-teal-900 text-white transition flex items-center gap-1.5 shadow-sm"
          >
            <Download className="w-4 h-4 text-[#d6b265]" />
            <span>Download Full JSON Backup</span>
          </button>

          <label className="px-4 py-2 text-xs font-bold rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 transition flex items-center gap-1.5 cursor-pointer border border-slate-200">
            <Upload className="w-4 h-4" />
            <span>Restore / Import Backup</span>
            <input
              type="file"
              accept=".json"
              onChange={handleFileRestore}
              className="hidden"
            />
          </label>

          <button
            onClick={handleResetToStartingData}
            className="px-3 py-2 text-xs font-semibold rounded-lg text-rose-700 hover:bg-rose-50 transition border border-rose-200"
          >
            Reset to Seed Data
          </button>
        </div>
      </div>

      {/* Category Manager */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-5 sm:p-6 space-y-4 text-xs">
        <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
          <Layers className="w-4 h-4 text-teal-800" />
          <h2 className="font-extrabold text-sm text-slate-900">
            AVA Custom Category &amp; Sub-Category Manager
          </h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="space-y-2">
            <label className="block text-[11px] font-bold text-slate-700">Add New Category</label>
            <div className="flex gap-2">
              <input
                type="text"
                placeholder="Category name..."
                value={newCatName}
                onChange={(e) => setNewCatName(e.target.value)}
                className="flex-1 p-2 bg-slate-50 border border-slate-200 rounded-lg text-xs"
              />
              <button
                type="button"
                onClick={handleAddCategory}
                className="px-3 py-2 font-bold bg-[#0b3d3a] text-white rounded-lg hover:bg-[#072725]"
              >
                Add
              </button>
            </div>
          </div>

          <div className="space-y-2">
            <label className="block text-[11px] font-bold text-slate-700">Add Sub-category to</label>
            <div className="flex gap-2">
              <select
                value={selectedCatForSub}
                onChange={(e) => setSelectedCatForSub(e.target.value)}
                className="p-2 bg-slate-50 border border-slate-200 rounded-lg text-xs w-1/3 truncate"
              >
                {Object.keys(settings.cats || {}).map((c) => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>
              <input
                type="text"
                placeholder="Sub-category name..."
                value={newSubName}
                onChange={(e) => setNewSubName(e.target.value)}
                className="flex-1 p-2 bg-slate-50 border border-slate-200 rounded-lg text-xs"
              />
              <button
                type="button"
                onClick={handleAddSubcategory}
                className="px-3 py-2 font-bold bg-[#0b3d3a] text-white rounded-lg hover:bg-[#072725]"
              >
                Add
              </button>
            </div>
          </div>
        </div>

        {/* Existing categories list */}
        <div className="pt-2">
          <span className="text-[11px] font-bold text-slate-500 uppercase block mb-2">Current Active Categories:</span>
          <div className="flex flex-wrap gap-1.5">
            {Object.keys(settings.cats || {}).map((c) => (
              <span
                key={c}
                className="px-2.5 py-1 rounded bg-slate-100 text-slate-800 border border-slate-200 text-xs font-semibold"
              >
                {c} ({settings.cats[c]?.length || 0})
              </span>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
