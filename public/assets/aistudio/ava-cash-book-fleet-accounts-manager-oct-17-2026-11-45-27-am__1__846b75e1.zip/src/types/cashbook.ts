export interface VoucherLine {
  d: string; // description
  f?: string; // from date YYYY-MM-DD
  t?: string; // to date YYYY-MM-DD
  q: number; // quantity
  u: number; // unit price in fils
  a: number; // amount in fils
}

export interface ReceiptInfo {
  id?: string;
  url?: string;
  dataUrl?: string;
  name?: string;
  mime?: string;
}

export interface Transaction {
  uid: string;
  date: string; // YYYY-MM-DD
  acc: 'Bank' | 'Petty';
  type: 'in' | 'out';
  amt: number; // amount in fils (1 AED = 100 fils)
  vat: number; // vat amount in fils
  desc: string;
  party: string;
  cat: string;
  sub: string;
  veh: string;
  ref: string;
  chq?: string;
  clr?: string; // cleared date YYYY-MM-DD
  bk?: string; // bank key
  sd?: string; // statement description text
  tr?: string; // transfer ID
  rcpt?: ReceiptInfo | null;
  by?: string;
  createdAt: number;
  updatedAt: number;
  deleted: boolean;
  pv?: string; // Payment Voucher reference (e.g. PV-10/2026-01)
  pm?: string; // Payment Method (Cheque, Cash, Bank Transfer)
  lines?: VoucherLine[];
  drv?: string; // Driver name
}

export interface VehicleInfo {
  plate: string;
  owner: string;
  vtype: string;
  model: string;
  seats: number;
  reg: string; // registration expiry date
  ins: string; // insurance expiry date
  permit?: string;
  pexp?: string;
  parea?: string;
}

export interface DriverInfo {
  name: string;
  phone: string;
  eid: string; // Emirates ID
  lic: string; // License number
  licExp: string; // License expiry YYYY-MM-DD
  visa: string; // Residence visa expiry YYYY-MM-DD
  note?: string;
  assignedVeh?: string;
}

export interface PayeeInfo {
  name: string;
  phone: string;
  trn: string; // Tax Registration Number
  bank: string; // Bank or IBAN
  note?: string;
}

export interface Settings {
  cats: Record<string, string[]>;
  veh: string[];
  ob: {
    Bank: number; // in fils
    Petty: number; // in fils
  };
  lockDate?: string;
  updatedAt: number;
  vinfo: Record<string, VehicleInfo>;
  co: {
    name: string;
    addr: string;
  };
  chqX: Record<string, { date?: string; note?: string }>;
  drivers?: DriverInfo[];
  payees?: PayeeInfo[];
  googleScriptUrl?: string;
  googleApiKey?: string;
  lastSyncTime?: number;
  deviceName?: string;
}

export interface CashbookData {
  app: string;
  version: string;
  exported: string;
  settings: Settings;
  tx: Transaction[];
}

export type TabId = 'dashboard' | 'cashbook' | 'vouchers' | 'cheques' | 'reconcile' | 'fleet' | 'drivers' | 'reports' | 'settings';
