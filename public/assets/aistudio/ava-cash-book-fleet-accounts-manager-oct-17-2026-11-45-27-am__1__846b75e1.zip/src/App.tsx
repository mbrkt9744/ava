/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { TabId, Transaction, Settings, CashbookData, VehicleInfo, DriverInfo, PayeeInfo } from './types/cashbook';
import { loadCashbookData, saveCashbookData } from './utils/storage';
import { calculateAccountBalances } from './utils/cheques';
import { Navbar } from './components/Navbar';
import { Dashboard } from './components/Dashboard';
import { CashBookView } from './components/CashBookView';
import { VoucherManager } from './components/VoucherManager';
import { ChequesView } from './components/ChequesView';
import { ReconciliationView } from './components/ReconciliationView';
import { FleetView } from './components/FleetView';
import { DriversPayeesView } from './components/DriversPayeesView';
import { ReportsView } from './components/ReportsView';
import { SettingsView } from './components/SettingsView';
import { TransactionModal } from './components/TransactionModal';

export default function App() {
  const [data, setData] = useState<CashbookData>(() => loadCashbookData());
  const [currentTab, setCurrentTab] = useState<TabId>('dashboard');
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [editingTx, setEditingTx] = useState<Transaction | null>(null);
  const [selectedVoucherNo, setSelectedVoucherNo] = useState<string | null>(null);
  const [isSyncing, setIsSyncing] = useState<boolean>(false);

  // Sync to localStorage whenever data changes
  useEffect(() => {
    saveCashbookData(data);
  }, [data]);

  const balances = calculateAccountBalances(data.tx, data.settings);

  // Historical descriptions for autocomplete
  const historicalDescriptions = Array.from(
    new Set(data.tx.map((t) => t.desc).filter(Boolean))
  );

  // Save Transaction (Add or Edit)
  const handleSaveTransaction = (txData: Partial<Transaction>) => {
    setData((prev) => {
      const existingIdx = prev.tx.findIndex((t) => t.uid === txData.uid);
      let updatedTxList = [...prev.tx];

      if (existingIdx >= 0) {
        updatedTxList[existingIdx] = {
          ...updatedTxList[existingIdx],
          ...txData,
          updatedAt: Date.now(),
        } as Transaction;
      } else {
        updatedTxList.unshift(txData as Transaction);
      }

      return {
        ...prev,
        tx: updatedTxList,
      };
    });
    setEditingTx(null);
  };

  // Soft Delete Transaction
  const handleDeleteTransaction = (uid: string) => {
    setData((prev) => ({
      ...prev,
      tx: prev.tx.map((t) => (t.uid === uid ? { ...t, deleted: true, updatedAt: Date.now() } : t)),
    }));
  };

  // Mark Cheque Cleared
  const handleMarkChequeCleared = (chqNumber: string, clearDate: string) => {
    setData((prev) => ({
      ...prev,
      tx: prev.tx.map((t) =>
        t.chq === chqNumber && t.acc === 'Bank' && t.type === 'out'
          ? { ...t, clr: clearDate, updatedAt: Date.now() }
          : t
      ),
    }));
  };

  // Cancel Cheque
  const handleMarkChequeCancelled = (chqNumber: string, note: string) => {
    setData((prev) => ({
      ...prev,
      settings: {
        ...prev.settings,
        chqX: {
          ...prev.settings.chqX,
          [chqNumber]: {
            date: new Date().toISOString().slice(0, 10),
            note,
          },
        },
      },
    }));
  };

  // Save Payment Voucher
  const handleSaveVoucher = (voucherTx: Transaction) => {
    setData((prev) => ({
      ...prev,
      tx: [voucherTx, ...prev.tx],
    }));
    setSelectedVoucherNo(voucherTx.pv || null);
  };

  // Save Vehicle
  const handleSaveVehicle = (plate: string, info: VehicleInfo) => {
    setData((prev) => {
      const vehList = prev.settings.veh || [];
      const updatedVehList = vehList.includes(plate) ? vehList : [...vehList, plate];
      return {
        ...prev,
        settings: {
          ...prev.settings,
          veh: updatedVehList,
          vinfo: {
            ...prev.settings.vinfo,
            [plate]: info,
          },
        },
      };
    });
  };

  // Save Driver
  const handleSaveDriver = (driver: DriverInfo) => {
    setData((prev) => {
      const existing = prev.settings.drivers || [];
      const idx = existing.findIndex((d) => d.name === driver.name);
      let updatedDrivers = [...existing];
      if (idx >= 0) {
        updatedDrivers[idx] = driver;
      } else {
        updatedDrivers.push(driver);
      }
      return {
        ...prev,
        settings: {
          ...prev.settings,
          drivers: updatedDrivers,
        },
      };
    });
  };

  // Save Payee
  const handleSavePayee = (payee: PayeeInfo) => {
    setData((prev) => {
      const existing = prev.settings.payees || [];
      const idx = existing.findIndex((p) => p.name === payee.name);
      let updatedPayees = [...existing];
      if (idx >= 0) {
        updatedPayees[idx] = payee;
      } else {
        updatedPayees.push(payee);
      }
      return {
        ...prev,
        settings: {
          ...prev.settings,
          payees: updatedPayees,
        },
      };
    });
  };

  // Apply Statement Reconciliations
  const handleApplyReconciliations = (
    clearedCheques: { chq: string; date: string }[],
    newTransactions: Transaction[]
  ) => {
    setData((prev) => {
      const clearedMap = new Map(clearedCheques.map((c) => [c.chq, c.date]));
      const updatedExisting = prev.tx.map((t) => {
        if (t.chq && clearedMap.has(t.chq)) {
          return { ...t, clr: clearedMap.get(t.chq)!, updatedAt: Date.now() };
        }
        return t;
      });

      return {
        ...prev,
        tx: [...newTransactions, ...updatedExisting],
      };
    });
  };

  // Restore whole database
  const handleRestoreData = (restored: CashbookData) => {
    setData(restored);
  };

  // Update Settings
  const handleUpdateSettings = (newSettings: Settings) => {
    setData((prev) => ({
      ...prev,
      settings: newSettings,
    }));
  };

  // Google Sheets sync
  const handleSyncNow = async () => {
    if (!data.settings.googleScriptUrl) {
      setCurrentTab('settings');
      alert('Please configure your Google Apps Script Web App URL first in Settings.');
      return;
    }

    setIsSyncing(true);
    try {
      const res = await fetch('/api/google-proxy', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          scriptUrl: data.settings.googleScriptUrl,
          payload: {
            op: 'sync',
            key: data.settings.googleApiKey,
            records: data.tx,
            settings: data.settings,
            device: data.settings.deviceName || 'Web App',
          },
        }),
      });

      const result = await res.json();
      if (result.ok) {
        alert(`Synced successfully with Google Sheets! (${result.changes?.length || 0} remote changes)`);
      } else {
        alert('Sync error: ' + (result.error || 'Failed to sync'));
      }
    } catch (err: any) {
      alert('Network error during sync: ' + err.message);
    } finally {
      setIsSyncing(false);
    }
  };

  const handleViewVoucher = (voucherNo: string) => {
    setSelectedVoucherNo(voucherNo);
    setCurrentTab('vouchers');
  };

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col text-slate-800">
      {/* Navbar */}
      <Navbar
        currentTab={currentTab}
        onSelectTab={setCurrentTab}
        bankBalance={balances.bankBalance}
        pettyBalance={balances.pettyBalance}
        onNewTransaction={() => {
          setEditingTx(null);
          setIsModalOpen(true);
        }}
        onNewVoucher={() => {
          setCurrentTab('vouchers');
        }}
        onSync={handleSyncNow}
        isSyncing={isSyncing}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {currentTab === 'dashboard' && (
          <Dashboard
            transactions={data.tx}
            settings={data.settings}
            onSelectTab={setCurrentTab}
            onNewTransaction={() => {
              setEditingTx(null);
              setIsModalOpen(true);
            }}
            onNewVoucher={() => setCurrentTab('vouchers')}
          />
        )}

        {currentTab === 'cashbook' && (
          <CashBookView
            transactions={data.tx}
            settings={data.settings}
            onNewTransaction={() => {
              setEditingTx(null);
              setIsModalOpen(true);
            }}
            onEditTransaction={(tx) => {
              setEditingTx(tx);
              setIsModalOpen(true);
            }}
            onDeleteTransaction={handleDeleteTransaction}
            onViewVoucher={handleViewVoucher}
          />
        )}

        {currentTab === 'vouchers' && (
          <VoucherManager
            transactions={data.tx}
            settings={data.settings}
            onSaveVoucher={handleSaveVoucher}
            selectedVoucherNo={selectedVoucherNo}
          />
        )}

        {currentTab === 'cheques' && (
          <ChequesView
            transactions={data.tx}
            settings={data.settings}
            onMarkChequeCleared={handleMarkChequeCleared}
            onMarkChequeCancelled={handleMarkChequeCancelled}
            onViewVoucher={handleViewVoucher}
          />
        )}

        {currentTab === 'reconcile' && (
          <ReconciliationView
            transactions={data.tx}
            settings={data.settings}
            onApplyMatches={handleApplyReconciliations}
          />
        )}

        {currentTab === 'fleet' && (
          <FleetView
            settings={data.settings}
            transactions={data.tx}
            onSaveVehicle={handleSaveVehicle}
          />
        )}

        {currentTab === 'drivers' && (
          <DriversPayeesView
            settings={data.settings}
            transactions={data.tx}
            onSaveDriver={handleSaveDriver}
            onSavePayee={handleSavePayee}
          />
        )}

        {currentTab === 'reports' && (
          <ReportsView
            transactions={data.tx}
            settings={data.settings}
          />
        )}

        {currentTab === 'settings' && (
          <SettingsView
            settings={data.settings}
            onUpdateSettings={handleUpdateSettings}
            fullData={data}
            onRestoreData={handleRestoreData}
            onSyncNow={handleSyncNow}
            isSyncing={isSyncing}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="bg-slate-900 text-slate-400 text-xs py-4 border-t border-slate-800 no-print">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className="font-extrabold text-white">AVA PASSENGERS TRANSPORT</span>
            <span>· Dubai, UAE</span>
            <span>· P.O. Box 91977</span>
          </div>
          <div className="text-[11px] text-slate-500">
            AVA Cash Book v3.4 · Offline PWA &amp; Google Cloud Sync Ready · All rights reserved
          </div>
        </div>
      </footer>

      {/* Transaction Entry Modal */}
      <TransactionModal
        isOpen={isModalOpen}
        onClose={() => {
          setIsModalOpen(false);
          setEditingTx(null);
        }}
        onSave={handleSaveTransaction}
        initialTx={editingTx}
        settings={data.settings}
        historicalDescriptions={historicalDescriptions}
      />
    </div>
  );
}
